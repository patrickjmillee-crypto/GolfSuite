#include "booking_manager.h"
#include <iostream>
#include <iomanip>
#include <algorithm>
#include <ctime>
#include <cmath>

namespace GolfCart {

BookingManager::BookingManager() {}

int BookingManager::createBooking(const std::string& customerName,
                                   const std::string& customerPhone,
                                   const std::string& customerId,
                                   std::time_t startTime,
                                   std::time_t endTime,
                                   double ratePerHour,
                                   const std::string& notes) {
    std::lock_guard<std::mutex> lock(m_mutex);

    Booking b;
    b.id           = m_nextId++;
    b.customerName = customerName;
    b.customerPhone= customerPhone;
    b.customerId   = customerId;
    b.startTime    = startTime;
    b.endTime      = endTime;
    b.ratePerHour  = ratePerHour;
    b.totalCost    = calculateCost(startTime, endTime, ratePerHour);
    b.notes        = notes;
    b.status       = BookingStatus::PENDING;

    m_bookings.push_back(b);
    if (m_bookingCb) m_bookingCb(b);
    return b.id;
}

bool BookingManager::confirmBooking(int bookingId, int cartId) {
    std::lock_guard<std::mutex> lock(m_mutex);
    Booking* b = findBooking(bookingId);
    if (!b || b->status != BookingStatus::PENDING) return false;
    b->status = BookingStatus::CONFIRMED;
    b->cartId = cartId;
    if (m_bookingCb) m_bookingCb(*b);
    return true;
}

bool BookingManager::startBooking(int bookingId) {
    std::lock_guard<std::mutex> lock(m_mutex);
    Booking* b = findBooking(bookingId);
    if (!b || b->status != BookingStatus::CONFIRMED) return false;
    b->status    = BookingStatus::ACTIVE;
    b->startTime = std::time(nullptr);
    if (m_bookingCb) m_bookingCb(*b);
    return true;
}

bool BookingManager::completeBooking(int bookingId) {
    std::lock_guard<std::mutex> lock(m_mutex);
    Booking* b = findBooking(bookingId);
    if (!b || b->status != BookingStatus::ACTIVE) return false;
    b->status   = BookingStatus::COMPLETED;
    b->endTime  = std::time(nullptr);
    b->totalCost = calculateCost(b->startTime, b->endTime, b->ratePerHour);
    if (m_bookingCb) m_bookingCb(*b);
    return true;
}

bool BookingManager::cancelBooking(int bookingId, const std::string& /*reason*/) {
    std::lock_guard<std::mutex> lock(m_mutex);
    Booking* b = findBooking(bookingId);
    if (!b) return false;
    b->status = BookingStatus::CANCELLED;
    if (m_bookingCb) m_bookingCb(*b);
    return true;
}

std::optional<Booking> BookingManager::getBooking(int id) const {
    std::lock_guard<std::mutex> lock(m_mutex);
    const Booking* b = findBooking(id);
    if (b) return *b;
    return std::nullopt;
}

std::vector<Booking> BookingManager::getActiveBookings() const {
    std::lock_guard<std::mutex> lock(m_mutex);
    std::vector<Booking> result;
    for (auto& b : m_bookings)
        if (b.status == BookingStatus::ACTIVE) result.push_back(b);
    return result;
}

std::vector<Booking> BookingManager::getPendingBookings() const {
    std::lock_guard<std::mutex> lock(m_mutex);
    std::vector<Booking> result;
    for (auto& b : m_bookings)
        if (b.status == BookingStatus::PENDING ||
            b.status == BookingStatus::CONFIRMED) result.push_back(b);
    return result;
}

std::vector<Booking> BookingManager::getBookingsForCart(int cartId) const {
    std::lock_guard<std::mutex> lock(m_mutex);
    std::vector<Booking> result;
    for (auto& b : m_bookings)
        if (b.cartId == cartId) result.push_back(b);
    return result;
}

std::vector<Booking> BookingManager::getBookingsForCustomer(const std::string& customerId) const {
    std::lock_guard<std::mutex> lock(m_mutex);
    std::vector<Booking> result;
    for (auto& b : m_bookings)
        if (b.customerId == customerId) result.push_back(b);
    return result;
}

std::vector<Booking> BookingManager::getTodaysBookings() const {
    std::lock_guard<std::mutex> lock(m_mutex);
    std::time_t now = std::time(nullptr);
    std::tm* tm = std::localtime(&now);
    tm->tm_hour = 0; tm->tm_min = 0; tm->tm_sec = 0;
    std::time_t today = std::mktime(tm);

    std::vector<Booking> result;
    for (auto& b : m_bookings)
        if (b.startTime >= today && b.status != BookingStatus::CANCELLED)
            result.push_back(b);
    return result;
}

bool BookingManager::isCartAvailable(int cartId, std::time_t start, std::time_t end) const {
    std::lock_guard<std::mutex> lock(m_mutex);
    for (auto& b : m_bookings) {
        if (b.cartId != cartId) continue;
        if (b.status == BookingStatus::CANCELLED ||
            b.status == BookingStatus::COMPLETED) continue;
        // Overlap check
        if (!(end <= b.startTime || start >= b.endTime)) return false;
    }
    return true;
}

std::vector<int> BookingManager::getAvailableCarts(std::time_t start, std::time_t end,
                                                     const std::vector<int>& allCartIds) const {
    std::vector<int> available;
    for (int id : allCartIds)
        if (isCartAvailable(id, start, end)) available.push_back(id);
    return available;
}

double BookingManager::getTodayRevenue() const {
    double total = 0.0;
    for (auto& b : getTodaysBookings())
        if (b.status == BookingStatus::COMPLETED) total += b.totalCost;
    return total;
}

double BookingManager::getMonthRevenue() const {
    std::lock_guard<std::mutex> lock(m_mutex);
    std::time_t now = std::time(nullptr);
    std::tm* tm = std::localtime(&now);
    tm->tm_mday = 1; tm->tm_hour = 0; tm->tm_min = 0; tm->tm_sec = 0;
    std::time_t monthStart = std::mktime(tm);
    double total = 0.0;
    for (auto& b : m_bookings)
        if (b.status == BookingStatus::COMPLETED && b.startTime >= monthStart)
            total += b.totalCost;
    return total;
}

double BookingManager::getTotalRevenue() const {
    std::lock_guard<std::mutex> lock(m_mutex);
    double total = 0.0;
    for (auto& b : m_bookings)
        if (b.status == BookingStatus::COMPLETED) total += b.totalCost;
    return total;
}

double BookingManager::calculateCost(std::time_t start, std::time_t end, double rate) const {
    double hours = std::difftime(end, start) / 3600.0;
    return std::max(0.0, hours) * rate;
}

Booking* BookingManager::findBooking(int id) {
    for (auto& b : m_bookings) if (b.id == id) return &b;
    return nullptr;
}

const Booking* BookingManager::findBooking(int id) const {
    for (auto& b : m_bookings) if (b.id == id) return &b;
    return nullptr;
}

void BookingManager::printBookings() const {
    std::lock_guard<std::mutex> lock(m_mutex);
    printf("\n  %-4s  %-20s  %-10s  Cart  %-10s  %s\n",
           "ID", "Customer", "Status", "Start", "Cost");
    printf("  %s\n", std::string(70, '-').c_str());
    for (auto& b : m_bookings) {
        char timeStr[32];
        std::tm* t = std::localtime(&b.startTime);
        std::strftime(timeStr, sizeof(timeStr), "%m/%d %H:%M", t);
        printf("  %-4d  %-20s  %-10s  %-4d  %-10s  $%.2f\n",
               b.id, b.customerName.c_str(), b.statusStr().c_str(),
               b.cartId, timeStr, b.totalCost);
    }
}

void BookingManager::printRevenueSummary() const {
    printf("\n  Revenue Summary\n");
    printf("  Today:    $%.2f\n", getTodayRevenue());
    printf("  Month:    $%.2f\n", getMonthRevenue());
    printf("  Total:    $%.2f\n", getTotalRevenue());
    printf("  Bookings: %zu\n",   m_bookings.size());
}

} // namespace GolfCart
