#include "fleet_manager.h"
#include "dashboard.h"
#include "api_server.h"
#include <iostream>
#include <csignal>
#include <cstdlib>
#include <string>
#include <thread>
#include <chrono>

static GolfCart::FleetManager* g_fleet = nullptr;
static GolfCart::ApiServer*    g_api   = nullptr;

void signalHandler(int sig) {
    std::cout << "\n  Shutting down...\n";
    if (g_api)   g_api->stop();
    if (g_fleet) g_fleet->stop();
    std::exit(0);
}

int main(int argc, char* argv[]) {
    std::signal(SIGINT,  signalHandler);
    std::signal(SIGTERM, signalHandler);

    int  port   = 8080;
    bool noUi   = false;
    bool noBrowser = false;

    for (int i = 1; i < argc; i++) {
        std::string arg = argv[i];
        if (arg == "--no-ui")      noUi      = true;
        if (arg == "--no-browser") noBrowser = true;
        if (arg == "--port" && i+1 < argc) port = std::stoi(argv[++i]);
    }

    std::cout << "\033[2J\033[H";
    std::cout << GolfCart::Color::CYAN
              << "\n  ⛳  Golf Cart Fleet Management System v1.0\n"
              << GolfCart::Color::RESET;

    // Initialize fleet
    GolfCart::FleetManager fleet;
    g_fleet = &fleet;
    fleet.initialize();
    fleet.start();
    std::cout << "  Fleet:  " << fleet.getAllCarts().size() << " carts online\n";

    // Start API + UI server
    GolfCart::ApiServer api(fleet, port);
    g_api = &api;
    api.start();

    std::cout << GolfCart::Color::GREEN
              << "\n  Dashboard → http://localhost:" << port << "\n"
              << GolfCart::Color::RESET;
    std::cout << "  Press Ctrl+C to stop.\n\n";

    // Try to open browser automatically (Linux/WSL)
    if (!noBrowser) {
        std::string url = "http://localhost:" + std::to_string(port);
        // WSL: use powershell.exe; native Linux: use xdg-open
        std::string cmd =
            "(powershell.exe /c start " + url + " 2>/dev/null) || "
            "(xdg-open " + url + " 2>/dev/null) || true";
        std::thread([cmd]{ std::system(cmd.c_str()); }).detach();
    }

    if (!noUi) {
        // Run terminal dashboard alongside the API
        GolfCart::Dashboard dashboard(fleet);
        dashboard.run();
    } else {
        // API-only mode — just keep alive
        while (true) std::this_thread::sleep_for(std::chrono::seconds(1));
    }

    api.stop();
    fleet.stop();
    return 0;
}
