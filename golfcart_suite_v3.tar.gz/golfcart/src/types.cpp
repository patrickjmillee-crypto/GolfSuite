#include "types.h"
#include <cmath>
#include <sstream>
#include <iomanip>
#include <ctime>

namespace GolfCart {

// ─── GPSCoordinate ───────────────────────────────────────────────────────────

double GPSCoordinate::distanceTo(const GPSCoordinate& other) const {
    // Haversine formula
    constexpr double R = 6371000.0; // Earth radius in meters
    double phi1 = latitude  * M_PI / 180.0;
    double phi2 = other.latitude  * M_PI / 180.0;
    double dphi = (other.latitude  - latitude)  * M_PI / 180.0;
    double dlam = (other.longitude - longitude) * M_PI / 180.0;

    double a = std::sin(dphi/2)*std::sin(dphi/2)
             + std::cos(phi1)*std::cos(phi2)
             * std::sin(dlam/2)*std::sin(dlam/2);
    double c = 2 * std::atan2(std::sqrt(a), std::sqrt(1-a));
    return R * c;
}

// ─── BatteryState ────────────────────────────────────────────────────────────

double BatteryState::estimatedRangeKm() const {
    // Simple model: 100% charge ~ 40 km range
    return (chargePercent / 100.0) * 40.0 * (healthPercent / 100.0);
}

// ─── GeofenceZone ────────────────────────────────────────────────────────────

bool GeofenceZone::contains(const GPSCoordinate& pos) const {
    return center.distanceTo(pos) <= radiusMeters;
}

// ─── Alert helpers ───────────────────────────────────────────────────────────

std::string Alert::levelStr() const {
    switch (level) {
        case AlertLevel::INFO:     return "INFO";
        case AlertLevel::WARNING:  return "WARNING";
        case AlertLevel::CRITICAL: return "CRITICAL";
        default: return "UNKNOWN";
    }
}

std::string Alert::timeStr() const {
    return timeToStr(timestamp);
}

// ─── Booking helpers ─────────────────────────────────────────────────────────

double Booking::durationHours() const {
    return std::difftime(endTime, startTime) / 3600.0;
}

std::string Booking::statusStr() const {
    switch (status) {
        case BookingStatus::PENDING:   return "PENDING";
        case BookingStatus::CONFIRMED: return "CONFIRMED";
        case BookingStatus::ACTIVE:    return "ACTIVE";
        case BookingStatus::COMPLETED: return "COMPLETED";
        case BookingStatus::CANCELLED: return "CANCELLED";
        default: return "UNKNOWN";
    }
}

// ─── MaintenanceRecord helpers ───────────────────────────────────────────────

std::string MaintenanceRecord::typeStr() const {
    switch (type) {
        case MaintenanceType::ROUTINE_CHECK:   return "Routine Check";
        case MaintenanceType::BATTERY_SERVICE: return "Battery Service";
        case MaintenanceType::TIRE_ROTATION:   return "Tire Rotation";
        case MaintenanceType::BRAKE_INSPECTION:return "Brake Inspection";
        case MaintenanceType::MOTOR_SERVICE:   return "Motor Service";
        case MaintenanceType::SOFTWARE_UPDATE: return "Software Update";
        case MaintenanceType::FULL_SERVICE:    return "Full Service";
        default: return "Unknown";
    }
}

// ─── Utility ─────────────────────────────────────────────────────────────────

std::string statusToStr(CartStatus s) {
    switch (s) {
        case CartStatus::AVAILABLE:   return "AVAILABLE";
        case CartStatus::IN_USE:      return "IN_USE";
        case CartStatus::CHARGING:    return "CHARGING";
        case CartStatus::MAINTENANCE: return "MAINTENANCE";
        case CartStatus::OFFLINE:     return "OFFLINE";
        case CartStatus::RESERVED:    return "RESERVED";
        default: return "UNKNOWN";
    }
}

std::string timeToStr(std::time_t t) {
    if (t == 0) return "N/A";
    std::tm* tm = std::localtime(&t);
    char buf[64];
    std::strftime(buf, sizeof(buf), "%Y-%m-%d %H:%M:%S", tm);
    return std::string(buf);
}

std::string currentTimeStr() {
    return timeToStr(std::time(nullptr));
}

} // namespace GolfCart
