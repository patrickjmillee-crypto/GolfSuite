#include "battery_monitor.h"
#include <iostream>
#include <iomanip>
#include <cmath>
#include <algorithm>
#include <ctime>

namespace GolfCart {

// ─── BatteryMonitor ──────────────────────────────────────────────────────────

BatteryMonitor::BatteryMonitor(int cartId, double capacityAh)
    : m_cartId(cartId)
{
    m_state.capacityAh    = capacityAh;
    m_state.chargePercent = 100.0;
    m_state.voltageV      = 48.0;
    m_state.healthPercent = 100.0;
    m_state.cycleCount    = 0;
}

BatteryState BatteryMonitor::readState() {
    std::lock_guard<std::mutex> lock(m_mutex);
    return m_state;
}

void BatteryMonitor::simulateDischarge(double powerWatts, double dtSeconds) {
    std::lock_guard<std::mutex> lock(m_mutex);

    double currentA = powerWatts / m_state.voltageV;
    double drainAh  = currentA * (dtSeconds / 3600.0);

    double totalAh = m_state.capacityAh * (m_state.healthPercent / 100.0);
    double usedAh  = totalAh * (1.0 - m_state.chargePercent / 100.0) + drainAh;
    m_state.chargePercent = std::max(0.0, 100.0 * (1.0 - usedAh / totalAh));

    // Model voltage sag under load
    m_state.voltageV   = 44.0 + 4.0 * (m_state.chargePercent / 100.0);
    m_state.currentA   = -currentA;
    m_state.isCharging = false;

    // Slight temperature rise under load
    m_state.temperatureC = std::min(45.0, 25.0 + powerWatts / 200.0);

    recordHistory();
    checkThresholds();
}

void BatteryMonitor::simulateCharge(double chargeRateA, double dtSeconds) {
    std::lock_guard<std::mutex> lock(m_mutex);

    double gainAh  = chargeRateA * (dtSeconds / 3600.0);
    double totalAh = m_state.capacityAh * (m_state.healthPercent / 100.0);
    double usedAh  = totalAh * (1.0 - m_state.chargePercent / 100.0);
    usedAh         = std::max(0.0, usedAh - gainAh);

    m_state.chargePercent = std::min(100.0, 100.0 * (1.0 - usedAh / totalAh));
    m_state.voltageV      = 44.0 + 4.0 * (m_state.chargePercent / 100.0);
    m_state.currentA      = chargeRateA;
    m_state.isCharging    = true;
    m_state.temperatureC  = std::min(35.0, 25.0 + chargeRateA * 0.3);

    if (m_state.chargePercent >= 100.0) {
        m_state.cycleCount++;
        m_state.healthPercent = std::max(70.0,
            100.0 - m_state.cycleCount * 0.02);
    }

    recordHistory();
}

void BatteryMonitor::setState(const BatteryState& state) {
    std::lock_guard<std::mutex> lock(m_mutex);
    m_state = state;
    recordHistory();
    checkThresholds();
}

std::deque<BatteryState> BatteryMonitor::getHistory() const {
    std::lock_guard<std::mutex> lock(m_mutex);
    return m_history;
}

double BatteryMonitor::getAverageDischargRateAh() const {
    std::lock_guard<std::mutex> lock(m_mutex);
    if (m_history.size() < 2) return 0.0;
    double total = 0.0;
    int    count = 0;
    for (auto& s : m_history) {
        if (s.currentA < 0) { total += std::abs(s.currentA); count++; }
    }
    return count > 0 ? total / count : 0.0;
}

double BatteryMonitor::estimateHealthPercent() const {
    std::lock_guard<std::mutex> lock(m_mutex);
    return m_state.healthPercent;
}

void BatteryMonitor::checkThresholds() {
    if (!m_alertCb) return;

    if (m_state.criticalBattery()) {
        Alert a;
        a.cartId    = m_cartId;
        a.level     = AlertLevel::CRITICAL;
        a.category  = "battery";
        a.message   = "CRITICAL: Battery at " +
                      std::to_string((int)m_state.chargePercent) + "% — return to charging station immediately!";
        a.timestamp = std::time(nullptr);
        m_alertCb(m_cartId, a);
    } else if (m_state.lowBattery()) {
        Alert a;
        a.cartId    = m_cartId;
        a.level     = AlertLevel::WARNING;
        a.category  = "battery";
        a.message   = "Low battery: " +
                      std::to_string((int)m_state.chargePercent) + "%. Please return to charging station.";
        a.timestamp = std::time(nullptr);
        m_alertCb(m_cartId, a);
    }

    if (m_state.temperatureC > 42.0) {
        Alert a;
        a.cartId    = m_cartId;
        a.level     = AlertLevel::WARNING;
        a.category  = "battery";
        a.message   = "Battery overheating: " +
                      std::to_string((int)m_state.temperatureC) + "°C";
        a.timestamp = std::time(nullptr);
        m_alertCb(m_cartId, a);
    }
}

void BatteryMonitor::recordHistory() {
    m_history.push_back(m_state);
    if (m_history.size() > HISTORY_SIZE) m_history.pop_front();
}

void BatteryMonitor::printStatus() const {
    std::lock_guard<std::mutex> lock(m_mutex);
    printf("  Battery: %.1f%%  |  %.1fV  |  %.1fA  |  %.1f°C  |  Health: %.0f%%  |  Cycles: %d\n",
           m_state.chargePercent, m_state.voltageV,
           m_state.currentA, m_state.temperatureC,
           m_state.healthPercent, m_state.cycleCount);
}

// ─── ChargingStationManager ──────────────────────────────────────────────────

void ChargingStationManager::addStation(const ChargingStation& station) {
    std::lock_guard<std::mutex> lock(m_mutex);
    m_stations.push_back(station);
}

void ChargingStationManager::loadDefaultStations() {
    ChargingStation s1;
    s1.id = 1; s1.name = "Charging Bay A";
    s1.location = GPSCoordinate(36.5668, -121.9502);
    s1.totalPorts = 6; s1.availablePorts = 6;
    s1.maxChargeRateKw = 7.2; s1.isOperational = true;
    m_stations.push_back(s1);

    ChargingStation s2;
    s2.id = 2; s2.name = "Charging Bay B";
    s2.location = GPSCoordinate(36.5672, -121.9508);
    s2.totalPorts = 4; s2.availablePorts = 4;
    s2.maxChargeRateKw = 7.2; s2.isOperational = true;
    m_stations.push_back(s2);
}

ChargingStation* ChargingStationManager::findNearest(const GPSCoordinate& pos) {
    std::lock_guard<std::mutex> lock(m_mutex);
    ChargingStation* nearest = nullptr;
    double minDist = 1e9;
    for (auto& s : m_stations) {
        if (!s.isOperational || !s.hasAvailablePort()) continue;
        double d = s.location.distanceTo(pos);
        if (d < minDist) { minDist = d; nearest = &s; }
    }
    return nearest;
}

const ChargingStation* ChargingStationManager::getStation(int id) const {
    std::lock_guard<std::mutex> lock(m_mutex);
    for (auto& s : m_stations) if (s.id == id) return &s;
    return nullptr;
}

std::vector<ChargingStation> ChargingStationManager::getAvailableStations() const {
    std::lock_guard<std::mutex> lock(m_mutex);
    std::vector<ChargingStation> avail;
    for (auto& s : m_stations)
        if (s.isOperational && s.hasAvailablePort()) avail.push_back(s);
    return avail;
}

bool ChargingStationManager::dockCart(int cartId, int stationId, int /*port*/) {
    std::lock_guard<std::mutex> lock(m_mutex);
    for (auto& s : m_stations) {
        if (s.id == stationId && s.availablePorts > 0) {
            s.availablePorts--;
            m_cartDocked[cartId] = stationId;
            return true;
        }
    }
    return false;
}

bool ChargingStationManager::undockCart(int cartId) {
    std::lock_guard<std::mutex> lock(m_mutex);
    auto it = m_cartDocked.find(cartId);
    if (it == m_cartDocked.end()) return false;
    for (auto& s : m_stations)
        if (s.id == it->second) { s.availablePorts++; break; }
    m_cartDocked.erase(it);
    return true;
}

void ChargingStationManager::printStations() const {
    std::lock_guard<std::mutex> lock(m_mutex);
    printf("\n  %-20s  Ports  Available  Rate\n", "Station");
    printf("  %s\n", std::string(50, '-').c_str());
    for (auto& s : m_stations) {
        printf("  %-20s  %5d  %9d  %.1f kW  %s\n",
               s.name.c_str(), s.totalPorts, s.availablePorts,
               s.maxChargeRateKw, s.isOperational ? "[OK]" : "[OFFLINE]");
    }
}

} // namespace GolfCart
