#include "tower_comm.h"
#include <sstream>
#include <iostream>
#include <chrono>
#include <algorithm>

namespace GolfCart {

// ─── Message ─────────────────────────────────────────────────────────────────

std::string Message::typeStr() const {
    switch (type) {
        case MessageType::TELEMETRY_UPDATE:  return "TELEMETRY";
        case MessageType::ALERT:             return "ALERT";
        case MessageType::COMMAND:           return "COMMAND";
        case MessageType::HEARTBEAT:         return "HEARTBEAT";
        case MessageType::BOOKING_UPDATE:    return "BOOKING";
        case MessageType::MAINTENANCE_UPDATE:return "MAINTENANCE";
        case MessageType::EMERGENCY:         return "EMERGENCY";
        default: return "UNKNOWN";
    }
}

std::string Message::serialize() const {
    std::ostringstream oss;
    oss << typeStr() << "|" << senderId << "|" << targetId
        << "|" << sequenceNum << "|" << timestamp << "|" << payload;
    return oss.str();
}

Message Message::deserialize(const std::string& raw) {
    Message m;
    std::istringstream ss(raw);
    std::string token;
    std::vector<std::string> parts;
    while (std::getline(ss, token, '|')) parts.push_back(token);
    if (parts.size() < 6) return m;

    // type
    std::string t = parts[0];
    if      (t == "TELEMETRY")   m.type = MessageType::TELEMETRY_UPDATE;
    else if (t == "ALERT")       m.type = MessageType::ALERT;
    else if (t == "COMMAND")     m.type = MessageType::COMMAND;
    else if (t == "HEARTBEAT")   m.type = MessageType::HEARTBEAT;
    else if (t == "EMERGENCY")   m.type = MessageType::EMERGENCY;
    else                         m.type = MessageType::COMMAND;

    m.senderId    = std::stoi(parts[1]);
    m.targetId    = std::stoi(parts[2]);
    m.sequenceNum = std::stoi(parts[3]);
    m.timestamp   = (std::time_t)std::stoll(parts[4]);
    m.payload     = parts[5];
    return m;
}

// ─── CartRadio ───────────────────────────────────────────────────────────────

CartRadio::CartRadio(int cartId) : m_cartId(cartId) {}

CartRadio::~CartRadio() { stop(); }

void CartRadio::start() {
    m_running = true;
    m_workerThread = std::thread(&CartRadio::workerLoop, this);
}

void CartRadio::stop() {
    m_running = false;
    m_cv.notify_all();
    if (m_workerThread.joinable()) m_workerThread.join();
}

bool CartRadio::send(const Message& msg) {
    // In real implementation: write to serial / UDP socket
    // Here: just log it
    (void)msg;
    return m_connected.load();
}

void CartRadio::injectMessage(const Message& msg) {
    {
        std::lock_guard<std::mutex> lock(m_queueMutex);
        m_inboundQueue.push(msg);
    }
    m_cv.notify_one();
}

void CartRadio::workerLoop() {
    while (m_running) {
        std::unique_lock<std::mutex> lock(m_queueMutex);
        m_cv.wait_for(lock, std::chrono::milliseconds(100),
            [this]{ return !m_inboundQueue.empty() || !m_running; });

        while (!m_inboundQueue.empty()) {
            Message msg = m_inboundQueue.front();
            m_inboundQueue.pop();
            lock.unlock();
            if (m_handler) m_handler(msg);
            lock.lock();
        }
    }
}

// ─── TowerComm ───────────────────────────────────────────────────────────────

TowerComm::TowerComm() {}

TowerComm::~TowerComm() { stop(); }

void TowerComm::start() {
    m_running = true;
    m_heartbeatThread = std::thread(&TowerComm::heartbeatLoop, this);
}

void TowerComm::stop() {
    m_running = false;
    if (m_heartbeatThread.joinable()) m_heartbeatThread.join();
}

void TowerComm::registerCart(int cartId, CartRadio* radio) {
    std::lock_guard<std::mutex> lock(m_mutex);
    m_radios[cartId] = radio;
    m_lastHeartbeat[cartId] = std::time(nullptr);

    // Set up inbound handler
    radio->setMessageHandler([this](const Message& msg) {
        handleIncoming(msg);
    });
}

void TowerComm::unregisterCart(int cartId) {
    std::lock_guard<std::mutex> lock(m_mutex);
    m_radios.erase(cartId);
    m_lastHeartbeat.erase(cartId);
}

void TowerComm::broadcastTelemetry(const CartTelemetry& telemetry) {
    // Build a lightweight telemetry payload
    std::ostringstream oss;
    oss << "lat=" << telemetry.position.latitude
        << ",lon=" << telemetry.position.longitude
        << ",batt=" << (int)telemetry.battery.chargePercent
        << ",speed=" << (int)telemetry.motion.speedKmh
        << ",status=" << statusToStr(telemetry.status);

    Message msg;
    msg.type      = MessageType::TELEMETRY_UPDATE;
    msg.senderId  = telemetry.cartId;
    msg.targetId  = 0; // tower
    msg.payload   = oss.str();
    msg.timestamp = telemetry.timestamp;
    msg.sequenceNum = ++m_seqCounter;

    std::lock_guard<std::mutex> lock(m_mutex);
    m_lastHeartbeat[telemetry.cartId] = std::time(nullptr);

    if (m_telemetryHandler) m_telemetryHandler(telemetry);
}

void TowerComm::broadcastAlert(const Alert& alert) {
    Message msg;
    msg.type      = MessageType::ALERT;
    msg.senderId  = alert.cartId;
    msg.targetId  = 0;
    msg.payload   = "[" + alert.levelStr() + "] " + alert.message;
    msg.timestamp = alert.timestamp;
    msg.sequenceNum = ++m_seqCounter;

    if (m_alertHandler) m_alertHandler(alert);
}

bool TowerComm::sendCommand(int cartId, const std::string& command) {
    std::lock_guard<std::mutex> lock(m_mutex);
    auto it = m_radios.find(cartId);
    if (it == m_radios.end()) return false;

    Message msg;
    msg.type      = MessageType::COMMAND;
    msg.senderId  = 0; // tower
    msg.targetId  = cartId;
    msg.payload   = command;
    msg.timestamp = std::time(nullptr);
    msg.sequenceNum = ++m_seqCounter;

    it->second->injectMessage(msg);
    return true;
}

bool TowerComm::sendEmergencyStop(int cartId) {
    return sendCommand(cartId, "EMERGENCY_STOP");
}

bool TowerComm::sendSpeedCap(int cartId, double maxKmh) {
    return sendCommand(cartId, "SPEED_CAP:" + std::to_string(maxKmh));
}

bool TowerComm::broadcastToAll(const std::string& command) {
    std::lock_guard<std::mutex> lock(m_mutex);
    for (auto& [id, radio] : m_radios) {
        Message msg;
        msg.type      = MessageType::COMMAND;
        msg.senderId  = 0;
        msg.targetId  = id;
        msg.payload   = command;
        msg.timestamp = std::time(nullptr);
        msg.sequenceNum = ++m_seqCounter;
        radio->injectMessage(msg);
    }
    return true;
}

void TowerComm::sendHeartbeat(int cartId) {
    std::lock_guard<std::mutex> lock(m_mutex);
    m_lastHeartbeat[cartId] = std::time(nullptr);
}

bool TowerComm::isCartResponsive(int cartId) const {
    std::lock_guard<std::mutex> lock(m_mutex);
    auto it = m_lastHeartbeat.find(cartId);
    if (it == m_lastHeartbeat.end()) return false;
    return (std::time(nullptr) - it->second) < 30; // 30s timeout
}

std::vector<int> TowerComm::getOfflineCarts() const {
    std::lock_guard<std::mutex> lock(m_mutex);
    std::vector<int> offline;
    std::time_t now = std::time(nullptr);
    for (auto& [id, ts] : m_lastHeartbeat)
        if (now - ts >= 30) offline.push_back(id);
    return offline;
}

void TowerComm::heartbeatLoop() {
    while (m_running) {
        std::this_thread::sleep_for(std::chrono::seconds(10));
        std::lock_guard<std::mutex> lock(m_mutex);
        std::time_t now = std::time(nullptr);
        for (auto& [id, ts] : m_lastHeartbeat) {
            if (now - ts > 30) {
                // Cart has gone silent — could raise an alert here
                (void)id;
            }
        }
    }
}

void TowerComm::handleIncoming(const Message& msg) {
    if (msg.type == MessageType::TELEMETRY_UPDATE ||
        msg.type == MessageType::HEARTBEAT) {
        std::lock_guard<std::mutex> lock(m_mutex);
        m_lastHeartbeat[msg.senderId] = std::time(nullptr);
    }
}

void TowerComm::printConnectionStatus() const {
    std::lock_guard<std::mutex> lock(m_mutex);
    printf("\n  Tower Communication Status\n");
    printf("  %-6s  %-12s  %s\n", "Cart", "Last Heard", "Status");
    printf("  %s\n", std::string(40, '-').c_str());
    std::time_t now = std::time(nullptr);
    for (auto& [id, ts] : m_lastHeartbeat) {
        long secs = (long)(now - ts);
        bool online = secs < 30;
        printf("  Cart%-2d  %10lds ago  %s\n", id, secs,
               online ? "[ONLINE]" : "[OFFLINE]");
    }
}

} // namespace GolfCart
