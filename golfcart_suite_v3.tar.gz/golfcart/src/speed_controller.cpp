#include "speed_controller.h"
#include <iostream>
#include <iomanip>
#include <algorithm>
#include <ctime>
#include <cmath>

namespace GolfCart {

// ─── SpeedController ─────────────────────────────────────────────────────────

SpeedController::SpeedController(int cartId)
    : m_cartId(cartId)
{
    m_motion.maxAllowedKmh = 25.0;
    m_motion.speedLimitActive = true;
}

void SpeedController::setTargetSpeed(double kmh) {
    std::lock_guard<std::mutex> lock(m_mutex);
    m_targetSpeed = std::max(0.0, kmh);
}

void SpeedController::applyZoneLimit(double maxKmh) {
    std::lock_guard<std::mutex> lock(m_mutex);
    m_zoneLimit = maxKmh;
    m_motion.maxAllowedKmh = effectiveLimit();
}

void SpeedController::emergencyStop() {
    std::lock_guard<std::mutex> lock(m_mutex);
    m_emergencyStop = true;
    m_targetSpeed   = 0.0;
    m_motion.speedKmh = 0.0;
    m_motion.isMoving = false;
}

void SpeedController::releaseEmergencyStop() {
    std::lock_guard<std::mutex> lock(m_mutex);
    m_emergencyStop = false;
}

void SpeedController::tick(double dtSeconds) {
    std::lock_guard<std::mutex> lock(m_mutex);
    if (m_emergencyStop) {
        m_motion.speedKmh = 0.0;
        m_motion.isMoving = false;
        return;
    }

    double limit  = effectiveLimit();
    double target = std::min(m_targetSpeed, limit);

    if (m_motion.speedKmh < target) {
        m_motion.speedKmh = std::min(target,
            m_motion.speedKmh + m_acceleration * dtSeconds);
    } else if (m_motion.speedKmh > target) {
        m_motion.speedKmh = std::max(target,
            m_motion.speedKmh - m_deceleration * dtSeconds);
    }

    m_motion.isMoving = m_motion.speedKmh > 0.1;
    checkSpeedViolation();
}

void SpeedController::setMeasuredSpeed(double kmh) {
    std::lock_guard<std::mutex> lock(m_mutex);
    m_motion.speedKmh = kmh;
    m_motion.isMoving = kmh > 0.1;
    checkSpeedViolation();
}

void SpeedController::setRemoteCap(double kmh) {
    std::lock_guard<std::mutex> lock(m_mutex);
    m_remoteCapKmh = kmh;
    m_motion.maxAllowedKmh = effectiveLimit();
}

void SpeedController::clearRemoteCap() {
    std::lock_guard<std::mutex> lock(m_mutex);
    m_remoteCapKmh = 0.0;
    m_motion.maxAllowedKmh = effectiveLimit();
}

MotionState SpeedController::getMotionState() const {
    std::lock_guard<std::mutex> lock(m_mutex);
    return m_motion;
}

bool SpeedController::isSpeeding() const {
    std::lock_guard<std::mutex> lock(m_mutex);
    return m_motion.speedKmh > effectiveLimit() + 2.0;
}

double SpeedController::getSpeedExcess() const {
    std::lock_guard<std::mutex> lock(m_mutex);
    return std::max(0.0, m_motion.speedKmh - effectiveLimit());
}

double SpeedController::effectiveLimit() const {
    double limit = m_absoluteMax;
    if (m_zoneLimit > 0.0)     limit = std::min(limit, m_zoneLimit);
    if (m_remoteCapKmh > 0.0)  limit = std::min(limit, m_remoteCapKmh);
    return limit;
}

void SpeedController::checkSpeedViolation() {
    if (!m_alertCb) return;
    double excess = m_motion.speedKmh - effectiveLimit();
    if (excess > 2.0) {
        Alert a;
        a.cartId    = m_cartId;
        a.level     = excess > 5.0 ? AlertLevel::CRITICAL : AlertLevel::WARNING;
        a.category  = "speed";
        a.message   = "Speed violation: " + std::to_string((int)m_motion.speedKmh) +
                      " km/h (limit: " + std::to_string((int)effectiveLimit()) + " km/h)";
        a.timestamp = std::time(nullptr);
        m_alertCb(m_cartId, a);
    }
}

void SpeedController::printStatus() const {
    std::lock_guard<std::mutex> lock(m_mutex);
    printf("  Speed: %.1f km/h  |  Limit: %.1f km/h  |  Target: %.1f km/h  |  %s\n",
           m_motion.speedKmh, effectiveLimit(), m_targetSpeed,
           m_emergencyStop ? "[ESTOP]" : (m_motion.isMoving ? "[MOVING]" : "[STOPPED]"));
}

// ─── SafetySystem ────────────────────────────────────────────────────────────

SafetySystem::SafetySystem(int cartId)
    : m_cartId(cartId) {}

void SafetySystem::runCheck(const CartTelemetry& telemetry) {
    checkBatteryLow(telemetry.battery);
    checkSpeedViolation(telemetry.motion.speedKmh,
                        telemetry.motion.maxAllowedKmh);
    checkTemperature(telemetry.battery.temperatureC);
}

bool SafetySystem::checkGeofenceViolation(const GPSCoordinate& /*pos*/, bool restricted) {
    if (restricted) {
        emitAlert(AlertLevel::CRITICAL, "geofence",
                  "Cart entered restricted zone! Stopping.");
        lockCart("Restricted zone violation");
        return true;
    }
    return false;
}

bool SafetySystem::checkSpeedViolation(double speed, double limit) {
    if (speed > limit + 2.0) {
        emitAlert(AlertLevel::WARNING, "speed",
                  "Speed " + std::to_string((int)speed) +
                  " km/h exceeds limit " + std::to_string((int)limit) + " km/h");
        return true;
    }
    return false;
}

bool SafetySystem::checkBatteryLow(const BatteryState& battery) {
    if (battery.criticalBattery()) {
        emitAlert(AlertLevel::CRITICAL, "battery",
                  "Critical battery level: " +
                  std::to_string((int)battery.chargePercent) + "%");
        return true;
    }
    return false;
}

bool SafetySystem::checkTemperature(double tempC) {
    if (tempC > 50.0) {
        emitAlert(AlertLevel::CRITICAL, "thermal",
                  "Dangerous temperature: " + std::to_string((int)tempC) + "°C");
        lockCart("Thermal protection");
        return true;
    }
    return false;
}

bool SafetySystem::checkTilt(double pitchDeg, double rollDeg) {
    if (std::abs(pitchDeg) > 20.0 || std::abs(rollDeg) > 15.0) {
        emitAlert(AlertLevel::CRITICAL, "tilt",
                  "Unsafe tilt detected — pitch:" +
                  std::to_string((int)pitchDeg) + "° roll:" +
                  std::to_string((int)rollDeg) + "°");
        lockCart("Tilt safety");
        return true;
    }
    return false;
}

void SafetySystem::lockCart(const std::string& reason) {
    std::lock_guard<std::mutex> lock(m_mutex);
    m_locked     = true;
    m_lockReason = reason;
    emitAlert(AlertLevel::CRITICAL, "lockout", "Cart LOCKED: " + reason);
}

void SafetySystem::unlockCart(const std::string& authorizedBy) {
    std::lock_guard<std::mutex> lock(m_mutex);
    m_locked     = false;
    m_lockReason = "";
    emitAlert(AlertLevel::INFO, "lockout",
              "Cart unlocked by: " + authorizedBy);
}

void SafetySystem::emitAlert(AlertLevel level, const std::string& category,
                              const std::string& msg) {
    Alert a;
    a.id        = m_alertIdCounter++;
    a.cartId    = m_cartId;
    a.level     = level;
    a.category  = category;
    a.message   = msg;
    a.timestamp = std::time(nullptr);
    m_safetyLog.push_back(a);
    if (m_cb) m_cb(m_cartId, a);
}

void SafetySystem::printSafetyLog() const {
    std::lock_guard<std::mutex> lock(m_mutex);
    printf("\n  Safety Log — Cart %d  (%zu entries)\n", m_cartId, m_safetyLog.size());
    for (auto& a : m_safetyLog) {
        printf("  [%s] %-8s  %s\n",
               a.timeStr().c_str(), a.levelStr().c_str(), a.message.c_str());
    }
}

} // namespace GolfCart
