#include "maintenance_scheduler.h"
#include <iostream>
#include <iomanip>
#include <algorithm>
#include <ctime>

namespace GolfCart {

MaintenanceScheduler::MaintenanceScheduler() {}

int MaintenanceScheduler::scheduleService(int cartId,
                                           MaintenanceType type,
                                           std::time_t scheduledDate,
                                           const std::string& technician,
                                           const std::string& notes) {
    std::lock_guard<std::mutex> lock(m_mutex);
    MaintenanceRecord r;
    r.id             = m_nextId++;
    r.cartId         = cartId;
    r.type           = type;
    r.scheduledDate  = scheduledDate;
    r.technicianName = technician;
    r.notes          = notes;
    r.completed      = false;
    m_records.push_back(r);
    if (m_cb) m_cb(r);
    return r.id;
}

bool MaintenanceScheduler::completeService(int recordId,
                                            const std::string& technicianName,
                                            const std::string& notes,
                                            double cost) {
    std::lock_guard<std::mutex> lock(m_mutex);
    for (auto& r : m_records) {
        if (r.id == recordId) {
            r.completed      = true;
            r.completedDate  = std::time(nullptr);
            r.technicianName = technicianName;
            r.notes          = notes;
            r.cost           = cost;
            if (m_cb) m_cb(r);
            return true;
        }
    }
    return false;
}

void MaintenanceScheduler::autoSchedule(int cartId, double odometryKm,
                                         int battCycleCount, double battHealthPct) {
    std::time_t now  = std::time(nullptr);
    std::time_t soon = now + 3 * 24 * 3600; // 3 days ahead

    // Routine check every 500 km
    long lastRoutineKm = 0;
    for (auto& r : m_records)
        if (r.cartId == cartId && r.type == MaintenanceType::ROUTINE_CHECK && r.completed)
            lastRoutineKm = (long)r.cost; // reusing cost field as km marker

    if (odometryKm - lastRoutineKm >= ROUTINE_CHECK_KM) {
        scheduleService(cartId, MaintenanceType::ROUTINE_CHECK, soon,
                        "Auto-Scheduler", "Triggered by odometry: " +
                        std::to_string((int)odometryKm) + " km");
    }

    // Battery service on cycle count
    bool hasBattService = false;
    for (auto& r : m_records)
        if (r.cartId == cartId &&
            r.type == MaintenanceType::BATTERY_SERVICE &&
            !r.completed) { hasBattService = true; break; }

    if (!hasBattService && battCycleCount > 0 &&
        battCycleCount % (int)BATTERY_SERVICE_CYCLES == 0) {
        scheduleService(cartId, MaintenanceType::BATTERY_SERVICE, soon,
                        "Auto-Scheduler",
                        "Cycle count: " + std::to_string(battCycleCount));
    }

    // Low battery health
    if (battHealthPct < BATTERY_HEALTH_THRESHOLD) {
        bool hasHealthAlert = false;
        for (auto& r : m_records)
            if (r.cartId == cartId &&
                r.type == MaintenanceType::BATTERY_SERVICE &&
                !r.completed) { hasHealthAlert = true; break; }
        if (!hasHealthAlert) {
            scheduleService(cartId, MaintenanceType::BATTERY_SERVICE, soon,
                            "Auto-Scheduler",
                            "Battery health degraded: " +
                            std::to_string((int)battHealthPct) + "%");
        }
    }
}

std::optional<MaintenanceRecord> MaintenanceScheduler::getRecord(int id) const {
    std::lock_guard<std::mutex> lock(m_mutex);
    for (auto& r : m_records) if (r.id == id) return r;
    return std::nullopt;
}

std::vector<MaintenanceRecord> MaintenanceScheduler::getDueServices() const {
    std::lock_guard<std::mutex> lock(m_mutex);
    std::time_t now = std::time(nullptr);
    std::vector<MaintenanceRecord> result;
    for (auto& r : m_records)
        if (!r.completed && r.scheduledDate <= now) result.push_back(r);
    return result;
}

std::vector<MaintenanceRecord> MaintenanceScheduler::getOverdueServices() const {
    std::lock_guard<std::mutex> lock(m_mutex);
    std::time_t now = std::time(nullptr);
    std::vector<MaintenanceRecord> result;
    for (auto& r : m_records)
        if (!r.completed && r.scheduledDate < now - 86400) result.push_back(r);
    return result;
}

std::vector<MaintenanceRecord> MaintenanceScheduler::getCartHistory(int cartId) const {
    std::lock_guard<std::mutex> lock(m_mutex);
    std::vector<MaintenanceRecord> result;
    for (auto& r : m_records)
        if (r.cartId == cartId) result.push_back(r);
    return result;
}

std::vector<MaintenanceRecord> MaintenanceScheduler::getUpcomingServices(int daysAhead) const {
    std::lock_guard<std::mutex> lock(m_mutex);
    std::time_t now    = std::time(nullptr);
    std::time_t cutoff = now + daysAhead * 86400;
    std::vector<MaintenanceRecord> result;
    for (auto& r : m_records)
        if (!r.completed && r.scheduledDate >= now && r.scheduledDate <= cutoff)
            result.push_back(r);
    return result;
}

bool MaintenanceScheduler::isCartDueForService(int cartId) const {
    for (auto& r : getDueServices())
        if (r.cartId == cartId) return true;
    return false;
}

double MaintenanceScheduler::getTotalMaintenanceCost(int cartId) const {
    std::lock_guard<std::mutex> lock(m_mutex);
    double total = 0.0;
    for (auto& r : m_records)
        if (r.cartId == cartId && r.completed) total += r.cost;
    return total;
}

double MaintenanceScheduler::getAverageServiceCost() const {
    std::lock_guard<std::mutex> lock(m_mutex);
    if (m_records.empty()) return 0.0;
    double total = 0.0; int count = 0;
    for (auto& r : m_records)
        if (r.completed) { total += r.cost; count++; }
    return count > 0 ? total / count : 0.0;
}

void MaintenanceScheduler::printSchedule() const {
    auto upcoming = getUpcomingServices(30);
    auto due      = getDueServices();
    printf("\n  %-4s  Cart  %-22s  %-12s  Technician\n",
           "ID", "Type", "Scheduled");
    printf("  %s\n", std::string(65, '-').c_str());

    auto printRecord = [](const MaintenanceRecord& r, const char* tag) {
        char buf[32];
        std::tm* t = std::localtime(&r.scheduledDate);
        std::strftime(buf, sizeof(buf), "%Y-%m-%d", t);
        printf("  %-4d  %-4d  %-22s  %-12s  %s %s\n",
               r.id, r.cartId, r.typeStr().c_str(), buf,
               r.technicianName.empty() ? "TBD" : r.technicianName.c_str(), tag);
    };

    for (auto& r : due)      printRecord(r, "[DUE]");
    for (auto& r : upcoming) printRecord(r, "");
}

void MaintenanceScheduler::printCartHistory(int cartId) const {
    auto history = getCartHistory(cartId);
    printf("\n  Maintenance History — Cart %d\n", cartId);
    printf("  %s\n", std::string(65, '-').c_str());
    for (auto& r : history) {
        printf("  [%s] %-22s  %s  $%.2f\n",
               r.completed ? "DONE" : "PEND",
               r.typeStr().c_str(),
               r.technicianName.c_str(),
               r.cost);
    }
    printf("  Total cost: $%.2f\n", getTotalMaintenanceCost(cartId));
}

} // namespace GolfCart
