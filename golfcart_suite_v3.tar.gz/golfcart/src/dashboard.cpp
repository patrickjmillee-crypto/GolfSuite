#include "dashboard.h"
#include <iostream>
#include <iomanip>
#include <sstream>
#include <limits>
#include <ctime>
#include <thread>
#include <chrono>

namespace GolfCart {

Dashboard::Dashboard(FleetManager& fleet) : m_fleet(fleet) {}

void Dashboard::run() {
    clearScreen();
    std::cout << Color::CYAN
              << "\n  +=================================================================+\n"
              << "  |         GOLF CART FLEET MANAGEMENT SYSTEM                     |\n"
              << "  |         Commercial Golf Course Edition v1.0                   |\n"
              << "  +=================================================================+\n"
              << Color::RESET;
    std::this_thread::sleep_for(std::chrono::milliseconds(400));

    while (true) {
        showMainMenu();
        int choice = promptInt("Select option");
        switch (choice) {
            case 1: showFleetOverview();   break;
            case 2: { int cid = promptInt("Enter Cart ID"); showCartDetails(cid); break; }
            case 3: showAlerts();          break;
            case 4: showBookings();        break;
            case 5: showMaintenance();     break;
            case 6: showGeofenceMap();     break;
            case 7: showRevenueSummary();  break;
            case 8: handleCartCommand();   break;
            case 9: handleBookingCommand();break;
            case 10:handleMaintenanceCommand(); break;
            case 0:
                printColored("\n  Shutting down Golf Cart Suite. Goodbye!\n\n", Color::CYAN);
                return;
            default:
                printColored("  Invalid option.\n", Color::YELLOW);
        }
        std::cout << "\n  Press ENTER to continue...";
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        std::cin.get();
        clearScreen();
    }
}

void Dashboard::showMainMenu() const {
    m_fleet.printDashboard();
    printColored("\n  MAIN MENU\n", Color::BOLD);
    printSeparator('-', 50);
    std::cout
        << "   1. Fleet Overview\n"
        << "   2. Cart Details\n"
        << "   3. Alerts\n"
        << "   4. Bookings\n"
        << "   5. Maintenance Schedule\n"
        << "   6. Geofence Map\n"
        << "   7. Revenue Summary\n"
        << "   8. Cart Commands\n"
        << "   9. New Booking\n"
        << "  10. Schedule Maintenance\n"
        << "   0. Exit\n";
    printSeparator('-', 50);
}

void Dashboard::showFleetOverview() const {
    printHeader("FLEET OVERVIEW");
    auto carts = m_fleet.getAllCarts();
    printf("  %-6s %-12s %-13s %-16s %-12s\n",
           "ID", "Name", "Status", "Battery", "Speed");
    printSeparator('-', 68);
    for (auto* cart : carts) {
        auto tel = cart->getTelemetry();
        std::string badge = statusBadge(tel.status);
        std::string bar   = batteryBar(tel.battery.chargePercent);
        printf("  %-6d %-12s %s%-13s%s %s %5.1f%%  %5.1f km/h\n",
               cart->getId(), cart->getName().c_str(),
               badge.c_str(), statusToStr(tel.status).c_str(), Color::RESET,
               bar.c_str(), tel.battery.chargePercent, tel.motion.speedKmh);
    }
    printSeparator('-', 68);
    auto stats = m_fleet.getStats();
    printf("\n  Total:%d  Available:%d  InUse:%d  Charging:%d  Maint:%d\n",
           stats.totalCarts, stats.availableCarts, stats.inUseCarts,
           stats.chargingCarts, stats.maintenanceCarts);
    printf("  Avg Battery: %.1f%%  |  Active Alerts: %d\n",
           stats.avgBatteryPct, stats.activeAlerts);
}

void Dashboard::showCartDetails(int cartId) const {
    printHeader("CART DETAILS -- Cart #" + std::to_string(cartId));
    CartAgent* cart = m_fleet.getCart(cartId);
    if (!cart) { printColored("  Cart not found.\n", Color::RED); return; }
    cart->printStatus();

    auto bookings = m_fleet.getBookings().getBookingsForCart(cartId);
    if (!bookings.empty()) {
        printf("\n  Bookings:\n");
        for (auto& b : bookings) {
            printf("    [%s] %s  %s  $%.2f\n",
                   b.statusStr().c_str(), b.customerName.c_str(),
                   timeToStr(b.startTime).c_str(), b.totalCost);
        }
    }
    auto history = m_fleet.getMaintenance().getCartHistory(cartId);
    if (!history.empty()) {
        printf("\n  Recent Maintenance:\n");
        int shown = 0;
        for (auto it = history.rbegin(); it != history.rend() && shown < 3; ++it, ++shown)
            printf("    [%s] %s -- %s\n",
                   it->completed ? "DONE" : "PENDING",
                   it->typeStr().c_str(), it->technicianName.c_str());
    }
}

void Dashboard::showAlerts() const {
    printHeader("ALERTS");
    auto alerts = m_fleet.getRecentAlerts(30);
    if (alerts.empty()) { printColored("  No alerts.\n", Color::GREEN); return; }
    printf("  %-10s %-5s %-10s %-10s  %s\n", "Time","Cart","Level","Category","Message");
    printSeparator('-', 72);
    for (auto it = alerts.rbegin(); it != alerts.rend(); ++it) {
        auto& a = *it;
        std::string badge = alertBadge(a.level);
        char timeBuf[20];
        std::tm* tm = std::localtime(&a.timestamp);
        std::strftime(timeBuf, sizeof(timeBuf), "%H:%M:%S", tm);
        printf("  %-8s %4d  %s%-8s%s  %-10s  %s\n",
               timeBuf, a.cartId,
               badge.c_str(), a.levelStr().c_str(), Color::RESET,
               a.category.c_str(), a.message.c_str());
    }
}

void Dashboard::showBookings() const {
    printHeader("BOOKINGS");
    m_fleet.getBookings().printBookings();
}

void Dashboard::showMaintenance() const {
    printHeader("MAINTENANCE SCHEDULE");
    m_fleet.getMaintenance().printSchedule();
    auto overdue = m_fleet.getMaintenance().getOverdueServices();
    if (!overdue.empty()) {
        printColored("\n  OVERDUE SERVICES:\n", Color::RED);
        for (auto& r : overdue)
            printf("  Cart %d -- %s\n", r.cartId, r.typeStr().c_str());
    }
}

void Dashboard::showGeofenceMap() const {
    printHeader("GEOFENCE MAP");
    m_fleet.getGeofences().printZoneMap();
    printf("\n  Cart Positions:\n");
    for (auto* cart : m_fleet.getAllCarts()) {
        auto tel = cart->getTelemetry();
        auto zones = m_fleet.getGeofences().getActiveZones(tel.position);
        printf("  %-12s  (%.6f, %.6f)  Zones: ",
               cart->getName().c_str(),
               tel.position.latitude, tel.position.longitude);
        if (zones.empty()) {
            printf("None");
        } else {
            for (int zid : zones) {
                const GeofenceZone* z = m_fleet.getGeofences().getZone(zid);
                if (z) printf("[%s] ", z->name.c_str());
            }
        }
        printf("\n");
    }
}

void Dashboard::showRevenueSummary() const {
    printHeader("REVENUE SUMMARY");
    m_fleet.getBookings().printRevenueSummary();
    printf("\n  Maintenance Costs:\n");
    for (auto* cart : m_fleet.getAllCarts()) {
        double cost = m_fleet.getMaintenance().getTotalMaintenanceCost(cart->getId());
        if (cost > 0)
            printf("  %-12s  $%.2f\n", cart->getName().c_str(), cost);
    }
}

void Dashboard::handleCartCommand() {
    printHeader("CART COMMANDS");
    printf("  1. Emergency Stop (one cart)\n");
    printf("  2. Emergency Stop ALL carts\n");
    printf("  3. Release Emergency Stop\n");
    printf("  4. Set Speed Cap (one cart)\n");
    printf("  5. Set Cart Status\n");
    printf("  6. Cap All Speeds (fleet-wide)\n");
    int choice = promptInt("Command");

    switch (choice) {
        case 1: {
            int id = promptInt("Cart ID");
            CartAgent* c = m_fleet.getCart(id);
            if (c) { c->emergencyStop(); printColored("  Emergency stop applied.\n", Color::YELLOW); }
            break;
        }
        case 2: {
            m_fleet.emergencyStopAll("Manual operator command");
            printColored("  ALL carts emergency stopped.\n", Color::RED);
            break;
        }
        case 3: {
            int id = promptInt("Cart ID");
            CartAgent* c = m_fleet.getCart(id);
            if (c) { c->releaseStop(); printColored("  Stop released.\n", Color::GREEN); }
            break;
        }
        case 4: {
            int id  = promptInt("Cart ID");
            int cap = promptInt("Max speed (km/h)");
            m_fleet.getTower().sendSpeedCap(id, (double)cap);
            printf("  Speed cap of %d km/h sent to Cart %d.\n", cap, id);
            break;
        }
        case 5: {
            int id = promptInt("Cart ID");
            printf("  1=Available 2=In_Use 3=Charging 4=Maintenance 5=Offline\n");
            int s = promptInt("Status");
            CartAgent* c = m_fleet.getCart(id);
            if (c && s >= 1 && s <= 5) {
                CartStatus statuses[] = {
                    CartStatus::AVAILABLE, CartStatus::IN_USE,
                    CartStatus::CHARGING,  CartStatus::MAINTENANCE,
                    CartStatus::OFFLINE
                };
                c->setStatus(statuses[s-1]);
                printf("  Status updated.\n");
            }
            break;
        }
        case 6: {
            int cap = promptInt("Cap all carts to (km/h)");
            m_fleet.capAllSpeeds((double)cap);
            printf("  Speed cap broadcast to all carts.\n");
            break;
        }
    }
}

void Dashboard::handleBookingCommand() {
    printHeader("NEW BOOKING");
    std::string name  = promptStr("Customer name");
    std::string phone = promptStr("Phone");
    std::string cid   = promptStr("Customer ID");
    int hours = promptInt("Duration (hours)");

    std::time_t start = std::time(nullptr) + 300;
    std::time_t end   = start + hours * 3600;

    std::vector<int> allIds;
    for (auto* c : m_fleet.getAllCarts()) allIds.push_back(c->getId());
    auto avail = m_fleet.getBookings().getAvailableCarts(start, end, allIds);

    if (avail.empty()) {
        printColored("  No carts available for that time slot.\n", Color::RED);
        return;
    }
    printf("  Available carts: ");
    for (int i : avail) printf("%d ", i);
    printf("\n");
    int cartId   = promptInt("Assign cart ID");
    int bookingId = m_fleet.getBookings().createBooking(name, phone, cid, start, end, 15.0);
    m_fleet.getBookings().confirmBooking(bookingId, cartId);
    printColored("  Booking #" + std::to_string(bookingId) +
                 " confirmed for Cart #" + std::to_string(cartId) + "\n", Color::GREEN);
}

void Dashboard::handleMaintenanceCommand() {
    printHeader("SCHEDULE MAINTENANCE");
    int cartId = promptInt("Cart ID");
    printf("  1=Routine 2=Battery 3=Tires 4=Brakes 5=Motor 6=Software 7=Full\n");
    int typeNum  = promptInt("Type");
    std::string tech  = promptStr("Technician name");
    std::string notes = promptStr("Notes");

    MaintenanceType types[] = {
        MaintenanceType::ROUTINE_CHECK,   MaintenanceType::BATTERY_SERVICE,
        MaintenanceType::TIRE_ROTATION,   MaintenanceType::BRAKE_INSPECTION,
        MaintenanceType::MOTOR_SERVICE,   MaintenanceType::SOFTWARE_UPDATE,
        MaintenanceType::FULL_SERVICE
    };
    if (typeNum < 1 || typeNum > 7) {
        printColored("  Invalid type.\n", Color::RED); return;
    }
    std::time_t scheduled = std::time(nullptr) + 86400;
    int id = m_fleet.getMaintenance().scheduleService(
        cartId, types[typeNum-1], scheduled, tech, notes);

    CartAgent* c = m_fleet.getCart(cartId);
    if (c) c->setStatus(CartStatus::MAINTENANCE);

    printColored("  Maintenance #" + std::to_string(id) +
                 " scheduled for Cart #" + std::to_string(cartId) + "\n", Color::GREEN);
}

// ─── Static Helpers ───────────────────────────────────────────────────────────

void Dashboard::clearScreen() {
    std::cout << "\033[2J\033[H";
}

void Dashboard::printHeader(const std::string& title) {
    clearScreen();
    printColored("\n  == " + title + " ==\n\n", Color::CYAN);
}

void Dashboard::printSeparator(char c, int width) {
    std::cout << "  " << std::string(width, c) << "\n";
}

void Dashboard::printColored(const std::string& text, const std::string& colorCode) {
    std::cout << colorCode << text << Color::RESET;
}

std::string Dashboard::batteryBar(double pct, int width) {
    int filled = (int)(pct / 100.0 * width);
    std::string bar = "[";
    const char* color = pct > 50 ? Color::GREEN : (pct > 20 ? Color::YELLOW : Color::RED);
    bar += color;
    bar += std::string(filled, '=');
    bar += std::string(width - filled, ' ');
    bar += Color::RESET;
    bar += "]";
    return bar;
}

std::string Dashboard::statusBadge(CartStatus s) {
    switch (s) {
        case CartStatus::AVAILABLE:   return Color::GREEN;
        case CartStatus::IN_USE:      return Color::BLUE;
        case CartStatus::CHARGING:    return Color::CYAN;
        case CartStatus::MAINTENANCE: return Color::YELLOW;
        case CartStatus::OFFLINE:     return Color::RED;
        case CartStatus::RESERVED:    return Color::MAGENTA;
        default: return Color::RESET;
    }
}

std::string Dashboard::alertBadge(AlertLevel l) {
    switch (l) {
        case AlertLevel::INFO:     return Color::CYAN;
        case AlertLevel::WARNING:  return Color::YELLOW;
        case AlertLevel::CRITICAL: return Color::RED;
        default: return Color::RESET;
    }
}

int Dashboard::promptInt(const std::string& prompt) {
    std::cout << "\n  " << Color::BOLD << prompt << ": " << Color::RESET;
    int val = 0;
    std::cin >> val;
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    return val;
}

std::string Dashboard::promptStr(const std::string& prompt) {
    std::cout << "  " << Color::BOLD << prompt << ": " << Color::RESET;
    std::string val;
    std::getline(std::cin, val);
    return val;
}

} // namespace GolfCart
