#include "cart_agent.h"
#include <iostream>
#include <iomanip>
#include <chrono>
#include <sstream>
#include <ctime>

namespace GolfCart {

CartAgent::CartAgent(const CartConfig& config,
                     GeofenceManager* geofences,
                     TowerComm* tower)
    : m_config(config)
    , m_geofences(geofences)
    , m_tower(tower)
{
    // Create subsystems
    m_gps     = std::make_unique<GPSEngine>(config.id);
    m_battery = std::make_unique<BatteryMonitor>(config.id, config.batteryCapacityAh);
    m_speed   = std::make_unique<SpeedController>(config.id);
    m_safety  = std::make_unique<SafetySystem>(config.id);
    m_radio   = std::make_unique<CartRadio>(config.id);

    m_speed->setAbsoluteMaxSpeed(config.maxSpeedKmh);

    // Wire alert callbacks → tower
    auto alertFn = [this](int /*cartId*/, const Alert& a) {
        if (m_tower) m_tower->broadcastAlert(a);
    };
    m_battery->setAlertCallback(alertFn);
    m_speed->setAlertCallback(alertFn);
    m_safety->setCallback(alertFn);

    // Wire remote commands from tower
    m_radio->setMessageHandler([this](const Message& msg) {
        applyRemoteCommand(msg.payload);
    });

    // Register radio with tower
    if (m_tower) m_tower->registerCart(config.id, m_radio.get());

    // Stagger starting position slightly per cart ID
    double latOffset = (config.id - 1) * 0.0003;
    m_gps->setSimulatedPosition(GPSCoordinate(
        36.5680 + latOffset, -121.9490, 30.0));
}

CartAgent::~CartAgent() {
    stop();
    if (m_tower) m_tower->unregisterCart(m_config.id);
}

void CartAgent::start() {
    m_running = true;
    m_radio->start();
    m_telemetryThread = std::thread(&CartAgent::telemetryLoop, this);
}

void CartAgent::stop() {
    m_running = false;
    m_radio->stop();
    if (m_telemetryThread.joinable()) m_telemetryThread.join();
}

CartStatus CartAgent::getStatus() const {
    std::lock_guard<std::mutex> lock(m_mutex);
    return m_status;
}

CartTelemetry CartAgent::getTelemetry() const {
    std::lock_guard<std::mutex> lock(m_mutex);
    return buildTelemetry();
}

void CartAgent::setTargetSpeed(double kmh) {
    if (m_safety->isLocked()) return;
    m_speed->setTargetSpeed(kmh);
    if (kmh > 0) setStatus(CartStatus::IN_USE);
}

void CartAgent::emergencyStop() {
    m_speed->emergencyStop();
    m_safety->lockCart("Emergency stop activated");
}

void CartAgent::releaseStop() {
    m_speed->releaseEmergencyStop();
    m_safety->unlockCart("Operator");
}

void CartAgent::startCharging(int stationId) {
    m_speed->setTargetSpeed(0.0);
    setStatus(CartStatus::CHARGING);
    (void)stationId;
}

void CartAgent::stopCharging() {
    setStatus(CartStatus::AVAILABLE);
}

void CartAgent::applyRemoteCommand(const std::string& cmd) {
    if (cmd == "EMERGENCY_STOP") {
        emergencyStop();
    } else if (cmd == "RELEASE_STOP") {
        releaseStop();
    } else if (cmd.find("SPEED_CAP:") == 0) {
        double cap = std::stod(cmd.substr(10));
        m_speed->setRemoteCap(cap);
    } else if (cmd == "CLEAR_SPEED_CAP") {
        m_speed->clearRemoteCap();
    } else if (cmd == "STATUS_REQUEST") {
        if (m_tower) m_tower->broadcastTelemetry(buildTelemetry());
    }
}

void CartAgent::setStatus(CartStatus s) {
    std::lock_guard<std::mutex> lock(m_mutex);
    m_status = s;
}

void CartAgent::telemetryLoop() {
    using namespace std::chrono;
    auto nextTick = steady_clock::now();

    while (m_running) {
        processTick();
        nextTick += milliseconds((int)(1000.0 / TICK_HZ));
        std::this_thread::sleep_until(nextTick);
    }
}

void CartAgent::processTick() {
    m_tickCount++;

    // 1. Read GPS & update geofences
    GPSCoordinate pos = m_gps->readPosition();

    // Simulate gentle movement if IN_USE
    {
        std::lock_guard<std::mutex> lock(m_mutex);
        if (m_status == CartStatus::IN_USE) {
            double heading = 45.0 + (m_config.id * 30.0); // spread carts
            m_gps->simulateMovement(heading,
                m_speed->getMotionState().speedKmh, DT);
        }
    }

    m_geofences->updateCartPosition(m_config.id, pos);

    // 2. Apply zone speed limit
    double zoneLimit = m_geofences->getSpeedLimit(pos);
    m_speed->applyZoneLimit(zoneLimit);

    // 3. Check restricted zone
    bool restricted = m_geofences->isRestricted(pos);
    if (restricted) {
        m_safety->checkGeofenceViolation(pos, true);
        m_speed->emergencyStop();
    }

    // 4. Speed physics tick
    m_speed->tick(DT);

    // 5. Battery discharge / charge simulation
    {
        std::lock_guard<std::mutex> lock(m_mutex);
        if (m_status == CartStatus::CHARGING) {
            m_battery->simulateCharge(15.0, DT); // 15A charge rate
        } else if (m_status == CartStatus::IN_USE) {
            double power = 800.0 + m_speed->getMotionState().speedKmh * 30.0;
            m_battery->simulateDischarge(power, DT);
        }
    }

    // 6. Safety check
    CartTelemetry tel = buildTelemetry();
    m_safety->runCheck(tel);

    // 7. Broadcast telemetry to tower every 5 ticks
    if (m_tickCount % 5 == 0 && m_tower) {
        m_tower->broadcastTelemetry(tel);
        m_tower->sendHeartbeat(m_config.id);
    }
}

CartTelemetry CartAgent::buildTelemetry() const {
    CartTelemetry t;
    t.cartId    = m_config.id;
    t.timestamp = std::time(nullptr);
    t.position  = m_gps->readPosition();
    t.battery   = m_battery->readState();
    t.motion    = m_speed->getMotionState();
    t.status    = m_status;
    return t;
}

void CartAgent::printStatus() const {
    auto tel = getTelemetry();
    printf("\n  ┌─ %s (ID:%d) ─────────────────────────────────\n",
           m_config.name.c_str(), m_config.id);
    printf("  │  Status:   %-12s  Model: %s\n",
           statusToStr(tel.status).c_str(), m_config.model.c_str());
    printf("  │  Battery:  %.1f%%  │  %.1fV  │  Health: %.0f%%\n",
           tel.battery.chargePercent, tel.battery.voltageV,
           tel.battery.healthPercent);
    printf("  │  Speed:    %.1f km/h  │  Limit: %.1f km/h\n",
           tel.motion.speedKmh, tel.motion.maxAllowedKmh);
    printf("  │  GPS:      %.6f, %.6f\n",
           tel.position.latitude, tel.position.longitude);
    printf("  │  Locked:   %s\n",
           m_safety->isLocked() ? "YES" : "No");
    printf("  └──────────────────────────────────────────────────\n");
}

} // namespace GolfCart
