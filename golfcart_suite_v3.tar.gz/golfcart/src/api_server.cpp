#include "api_server.h"
#include <iostream>
#include <iomanip>
#include <sstream>
#include <ctime>

namespace GolfCart {

// ─── Helpers ─────────────────────────────────────────────────────────────────

static std::string joinFields(const std::vector<std::string>& parts) {
    std::string out;
    for (size_t i = 0; i < parts.size(); ++i) {
        if (i) out += ',';
        out += parts[i];
    }
    return out;
}

// ─── Constructor / Destructor ─────────────────────────────────────────────────

ApiServer::ApiServer(FleetManager& fleet, int port)
    : m_fleet(fleet), m_port(port) {}

ApiServer::~ApiServer() { stop(); }

void ApiServer::start() {
    setupRoutes();
    m_running = true;
    m_thread = std::thread([this]() {
        std::cout << "  [API] Server listening on http://0.0.0.0:" << m_port << "\n";
        m_svr.listen("0.0.0.0", m_port);
    });
}

void ApiServer::stop() {
    if (m_running.exchange(false)) {
        m_svr.stop();
        if (m_thread.joinable()) m_thread.join();
    }
}

void ApiServer::setCORS(httplib::Response& res) {
    res.set_header("Access-Control-Allow-Origin",  "*");
    res.set_header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
    res.set_header("Access-Control-Allow-Headers", "Content-Type");
    res.set_header("Cache-Control",                "no-cache");
}

// ─── Route Setup ─────────────────────────────────────────────────────────────

void ApiServer::setupRoutes() {

    // Pre-flight CORS
    m_svr.Options(".*", [this](const httplib::Request&, httplib::Response& res) {
        setCORS(res);
        res.status = 204;
    });

    // ── GET / ── serve embedded web dashboard ────────────────────────────────
    m_svr.Get("/", [](const httplib::Request&, httplib::Response& res) {
        res.set_content(getEmbeddedUI(), "text/html");
    });

    // ── GET /api/fleet ────────────────────────────────────────────────────────
    m_svr.Get("/api/fleet", [this](const httplib::Request&, httplib::Response& res) {
        setCORS(res);
        res.set_content(serializeFleetStats(), "application/json");
    });

    // ── GET /api/carts ────────────────────────────────────────────────────────
    m_svr.Get("/api/carts", [this](const httplib::Request&, httplib::Response& res) {
        setCORS(res);
        res.set_content(serializeAllCarts(), "application/json");
    });

    // ── GET /api/carts/:id ────────────────────────────────────────────────────
    m_svr.Get(R"(/api/carts/(\d+))", [this](const httplib::Request& req, httplib::Response& res) {
        setCORS(res);
        int id = std::stoi(req.matches[1]);
        CartAgent* c = m_fleet.getCart(id);
        if (!c) { res.status = 404; res.set_content(R"({"error":"cart not found"})", "application/json"); return; }
        res.set_content(serializeCart(c), "application/json");
    });

    // ── POST /api/carts/:id/command ───────────────────────────────────────────
    m_svr.Post(R"(/api/carts/(\d+)/command)", [this](const httplib::Request& req, httplib::Response& res) {
        setCORS(res);
        int id = std::stoi(req.matches[1]);
        CartAgent* c = m_fleet.getCart(id);
        if (!c) { res.status = 404; res.set_content(R"({"error":"cart not found"})", "application/json"); return; }

        // Parse "command" field from simple JSON body
        std::string cmd;
        auto body = req.body;
        auto pos = body.find("\"command\"");
        if (pos != std::string::npos) {
            auto q1 = body.find('"', pos + 9);
            if (q1 != std::string::npos) {
                auto q2 = body.find('"', q1 + 1);
                if (q2 != std::string::npos)
                    cmd = body.substr(q1 + 1, q2 - q1 - 1);
            }
        }
        // Parse optional "value" field
        double value = 0.0;
        auto vpos = body.find("\"value\"");
        if (vpos != std::string::npos) {
            auto col = body.find(':', vpos);
            if (col != std::string::npos) value = std::stod(body.substr(col + 1));
        }

        if      (cmd == "emergency_stop")  c->emergencyStop();
        else if (cmd == "release_stop")    c->releaseStop();
        else if (cmd == "start_charging")  c->startCharging(1);
        else if (cmd == "stop_charging")   c->stopCharging();
        else if (cmd == "speed_cap")       m_fleet.getTower().sendSpeedCap(id, value);
        else if (cmd == "clear_speed_cap") m_fleet.getTower().sendCommand(id, "CLEAR_SPEED_CAP");
        else if (cmd == "set_speed") {
            if (value > 0) c->setTargetSpeed(value);
        } else if (cmd == "set_status") {
            int s = (int)value;
            CartStatus statuses[] = {
                CartStatus::AVAILABLE, CartStatus::IN_USE,
                CartStatus::CHARGING,  CartStatus::MAINTENANCE, CartStatus::OFFLINE
            };
            if (s >= 1 && s <= 5) c->setStatus(statuses[s-1]);
        } else {
            res.status = 400;
            res.set_content(R"({"error":"unknown command"})", "application/json");
            return;
        }
        res.set_content(R"({"ok":true})", "application/json");
    });

    // ── POST /api/fleet/emergency ─────────────────────────────────────────────
    m_svr.Post("/api/fleet/emergency", [this](const httplib::Request&, httplib::Response& res) {
        setCORS(res);
        m_fleet.emergencyStopAll("Web dashboard emergency stop");
        res.set_content(R"({"ok":true,"message":"Emergency stop sent to all carts"})", "application/json");
    });

    // ── POST /api/fleet/speedcap ──────────────────────────────────────────────
    m_svr.Post("/api/fleet/speedcap", [this](const httplib::Request& req, httplib::Response& res) {
        setCORS(res);
        double cap = 25.0;
        auto vpos = req.body.find("\"value\"");
        if (vpos != std::string::npos) {
            auto col = req.body.find(':', vpos);
            if (col != std::string::npos) cap = std::stod(req.body.substr(col + 1));
        }
        m_fleet.capAllSpeeds(cap);
        res.set_content(R"({"ok":true})", "application/json");
    });

    // ── GET /api/bookings ─────────────────────────────────────────────────────
    m_svr.Get("/api/bookings", [this](const httplib::Request&, httplib::Response& res) {
        setCORS(res);
        res.set_content(serializeBookings(), "application/json");
    });

    // ── POST /api/bookings ────────────────────────────────────────────────────
    m_svr.Post("/api/bookings", [this](const httplib::Request& req, httplib::Response& res) {
        setCORS(res);
        auto extract = [&](const std::string& key) -> std::string {
            auto pos = req.body.find("\"" + key + "\"");
            if (pos == std::string::npos) return "";
            auto col = req.body.find(':', pos);
            if (col == std::string::npos) return "";
            auto q1  = req.body.find('"', col + 1);
            if (q1  == std::string::npos) return "";
            auto q2  = req.body.find('"', q1 + 1);
            if (q2  == std::string::npos) return "";
            return req.body.substr(q1 + 1, q2 - q1 - 1);
        };
        auto extractNum = [&](const std::string& key, double def) -> double {
            auto pos = req.body.find("\"" + key + "\"");
            if (pos == std::string::npos) return def;
            auto col = req.body.find(':', pos);
            if (col == std::string::npos) return def;
            try { return std::stod(req.body.substr(col + 1)); } catch(...) { return def; }
        };

        std::string name  = extract("name");
        std::string phone = extract("phone");
        std::string cid   = extract("customerId");
        int    cartId  = (int)extractNum("cartId", -1);
        int    hours   = (int)extractNum("hours", 1);
        double rate    = extractNum("rate", 15.0);

        if (name.empty()) {
            res.status = 400;
            res.set_content(R"({"error":"name required"})", "application/json");
            return;
        }
        std::time_t start = std::time(nullptr) + 300;
        std::time_t end   = start + hours * 3600;

        int bid = m_fleet.getBookings().createBooking(name, phone, cid.empty() ? name : cid, start, end, rate);
        if (cartId > 0) m_fleet.getBookings().confirmBooking(bid, cartId);

        res.set_content(obj(joinFields({jKVi("id", bid), jKVb("ok", true)})), "application/json");
    });

    // ── PUT /api/bookings/:id/:action ─────────────────────────────────────────
    m_svr.Put(R"(/api/bookings/(\d+)/(start|complete|cancel))", [this](const httplib::Request& req, httplib::Response& res) {
        setCORS(res);
        int id = std::stoi(req.matches[1]);
        std::string action = req.matches[2];
        bool ok = false;
        if      (action == "start")    ok = m_fleet.getBookings().startBooking(id);
        else if (action == "complete") ok = m_fleet.getBookings().completeBooking(id);
        else if (action == "cancel")   ok = m_fleet.getBookings().cancelBooking(id);
        res.set_content(ok ? R"({"ok":true})" : R"({"ok":false,"error":"invalid state"})", "application/json");
    });

    // ── GET /api/alerts ───────────────────────────────────────────────────────
    m_svr.Get("/api/alerts", [this](const httplib::Request& req, httplib::Response& res) {
        setCORS(res);
        int n = 50;
        if (req.has_param("n")) n = std::stoi(req.get_param_value("n"));
        res.set_content(serializeAlerts(n), "application/json");
    });

    // ── GET /api/maintenance ──────────────────────────────────────────────────
    m_svr.Get("/api/maintenance", [this](const httplib::Request&, httplib::Response& res) {
        setCORS(res);
        res.set_content(serializeMaintenance(), "application/json");
    });

    // ── POST /api/maintenance ─────────────────────────────────────────────────
    m_svr.Post("/api/maintenance", [this](const httplib::Request& req, httplib::Response& res) {
        setCORS(res);
        auto extractStr = [&](const std::string& key) -> std::string {
            auto pos = req.body.find("\"" + key + "\"");
            if (pos == std::string::npos) return "";
            auto col = req.body.find(':', pos);
            if (col == std::string::npos) return "";
            auto q1  = req.body.find('"', col + 1);
            if (q1  == std::string::npos) return "";
            auto q2  = req.body.find('"', q1 + 1);
            if (q2  == std::string::npos) return "";
            return req.body.substr(q1 + 1, q2 - q1 - 1);
        };
        auto extractNum = [&](const std::string& key, double def) -> double {
            auto pos = req.body.find("\"" + key + "\"");
            if (pos == std::string::npos) return def;
            auto col = req.body.find(':', pos);
            if (col == std::string::npos) return def;
            try { return std::stod(req.body.substr(col + 1)); } catch(...) { return def; }
        };

        int cartId = (int)extractNum("cartId", 0);
        int typeNum = (int)extractNum("type", 1);
        std::string tech  = extractStr("technician");
        std::string notes = extractStr("notes");

        MaintenanceType types[] = {
            MaintenanceType::ROUTINE_CHECK,    MaintenanceType::BATTERY_SERVICE,
            MaintenanceType::TIRE_ROTATION,    MaintenanceType::BRAKE_INSPECTION,
            MaintenanceType::MOTOR_SERVICE,    MaintenanceType::SOFTWARE_UPDATE,
            MaintenanceType::FULL_SERVICE
        };
        if (typeNum < 1 || typeNum > 7 || cartId <= 0) {
            res.status = 400; res.set_content(R"({"error":"invalid input"})", "application/json"); return;
        }
        std::time_t scheduled = std::time(nullptr) + 86400;
        int id = m_fleet.getMaintenance().scheduleService(
            cartId, types[typeNum-1], scheduled, tech, notes);
        CartAgent* c = m_fleet.getCart(cartId);
        if (c) c->setStatus(CartStatus::MAINTENANCE);
        res.set_content(obj(joinFields({jKVi("id", id), jKVb("ok", true)})), "application/json");
    });

    // ── PUT /api/maintenance/:id/complete ─────────────────────────────────────
    m_svr.Put(R"(/api/maintenance/(\d+)/complete)", [this](const httplib::Request& req, httplib::Response& res) {
        setCORS(res);
        int id = std::stoi(req.matches[1]);
        bool ok = m_fleet.getMaintenance().completeService(id, "Technician", "Completed via dashboard", 0.0);
        res.set_content(ok ? R"({"ok":true})" : R"({"ok":false})", "application/json");
    });

    // ── GET /api/geofences ────────────────────────────────────────────────────
    m_svr.Get("/api/geofences", [this](const httplib::Request&, httplib::Response& res) {
        setCORS(res);
        res.set_content(serializeGeofences(), "application/json");
    });

    // ── GET /api/revenue ──────────────────────────────────────────────────────
    m_svr.Get("/api/revenue", [this](const httplib::Request&, httplib::Response& res) {
        setCORS(res);
        res.set_content(serializeRevenue(), "application/json");
    });

    // ── GET /api/tower ────────────────────────────────────────────────────────
    m_svr.Get("/api/tower", [this](const httplib::Request&, httplib::Response& res) {
        setCORS(res);
        res.set_content(serializeTowerStatus(), "application/json");
    });

    // ── GET /health ───────────────────────────────────────────────────────────
    m_svr.Get("/health", [](const httplib::Request&, httplib::Response& res) {
        res.set_content(R"({"status":"ok"})", "application/json");
    });
}

// ─── Serializers ─────────────────────────────────────────────────────────────

std::string ApiServer::serializeFleetStats() {
    auto s = m_fleet.getStats();
    return obj(joinFields({
        jKVi("totalCarts",       s.totalCarts),
        jKVi("availableCarts",   s.availableCarts),
        jKVi("inUseCarts",       s.inUseCarts),
        jKVi("chargingCarts",    s.chargingCarts),
        jKVi("maintenanceCarts", s.maintenanceCarts),
        jKVi("offlineCarts",     s.offlineCarts),
        jKVd("avgBatteryPct",    s.avgBatteryPct, 1),
        jKVd("avgSpeedKmh",      s.avgSpeedKmh,   1),
        jKVi("activeAlerts",     s.activeAlerts),
        jKVd("todayRevenue",     s.todayRevenue,  2),
        jKVi("todayBookings",    s.todayBookings),
        jKVs("timestamp",        currentTimeStr())
    }));
}

std::string ApiServer::serializeCart(CartAgent* c) {
    auto tel = c->getTelemetry();
    auto& cfg = c->getConfig();
    return obj(joinFields({
        jKVi("id",             cfg.id),
        jKVs("name",           cfg.name),
        jKVs("model",          cfg.model),
        jKVs("color",          cfg.color),
        jKVs("serialNumber",   cfg.serialNumber),
        jKVi("seatCapacity",   cfg.seatCapacity),
        jKVs("status",         statusToStr(tel.status)),
        jKVd("batteryPct",     tel.battery.chargePercent, 1),
        jKVd("batteryVoltage", tel.battery.voltageV, 2),
        jKVd("batteryCurrent", tel.battery.currentA, 2),
        jKVd("batteryTempC",   tel.battery.temperatureC, 1),
        jKVd("batteryHealth",  tel.battery.healthPercent, 1),
        jKVi("batteryCycles",  tel.battery.cycleCount),
        jKVb("isCharging",     tel.battery.isCharging),
        jKVd("speedKmh",       tel.motion.speedKmh, 1),
        jKVd("maxSpeedKmh",    tel.motion.maxAllowedKmh, 1),
        jKVb("isMoving",       tel.motion.isMoving),
        jKVd("latitude",       tel.position.latitude, 6),
        jKVd("longitude",      tel.position.longitude, 6),
        jKVb("gpsValid",       tel.position.valid),
        jKVd("estimatedRangeKm", tel.battery.estimatedRangeKm(), 1),
        jKVs("timestamp",      timeToStr(tel.timestamp))
    }));
}

std::string ApiServer::serializeAllCarts() {
    auto carts = m_fleet.getAllCarts();
    std::string items;
    for (size_t i = 0; i < carts.size(); ++i) {
        if (i) items += ',';
        items += serializeCart(carts[i]);
    }
    return arr(items);
}

std::string ApiServer::serializeBookings() {
    auto all = m_fleet.getBookings().getTodaysBookings();
    // Also include recent completed/cancelled
    std::string items;
    bool first = true;
    auto addBooking = [&](const Booking& b) {
        if (!first) items += ',';
        first = false;
        char startBuf[32], endBuf[32];
        std::tm* ts = std::localtime(&b.startTime);
        std::strftime(startBuf, sizeof(startBuf), "%H:%M", ts);
        std::tm* te = std::localtime(&b.endTime);
        std::strftime(endBuf, sizeof(endBuf), "%H:%M", te);
        items += obj(joinFields({
            jKVi("id",           b.id),
            jKVs("customerName", b.customerName),
            jKVs("customerPhone",b.customerPhone),
            jKVi("cartId",       b.cartId),
            jKVs("startTime",    startBuf),
            jKVs("endTime",      endBuf),
            jKVd("durationHours",b.durationHours(), 1),
            jKVs("status",       b.statusStr()),
            jKVd("totalCost",    b.totalCost, 2),
            jKVd("ratePerHour",  b.ratePerHour, 2)
        }));
    };
    for (auto& b : all) addBooking(b);
    return arr(items);
}

std::string ApiServer::serializeAlerts(int n) {
    auto alerts = m_fleet.getRecentAlerts(n);
    std::string items;
    bool first = true;
    for (auto it = alerts.rbegin(); it != alerts.rend(); ++it) {
        auto& a = *it;
        if (!first) items += ',';
        first = false;
        items += obj(joinFields({
            jKVi("id",       a.id),
            jKVi("cartId",   a.cartId),
            jKVs("level",    a.levelStr()),
            jKVs("category", a.category),
            jKVs("message",  a.message),
            jKVs("time",     a.timeStr()),
            jKVb("acknowledged", a.acknowledged)
        }));
    }
    return arr(items);
}

std::string ApiServer::serializeMaintenance() {
    auto upcoming = m_fleet.getMaintenance().getUpcomingServices(30);
    auto due      = m_fleet.getMaintenance().getDueServices();
    std::string items;
    bool first = true;
    auto addRec = [&](const MaintenanceRecord& r, const std::string& tag) {
        if (!first) items += ',';
        first = false;
        char buf[32];
        std::tm* t = std::localtime(&r.scheduledDate);
        std::strftime(buf, sizeof(buf), "%Y-%m-%d", t);
        items += obj(joinFields({
            jKVi("id",         r.id),
            jKVi("cartId",     r.cartId),
            jKVs("type",       r.typeStr()),
            jKVs("scheduled",  buf),
            jKVs("technician", r.technicianName),
            jKVs("notes",      r.notes),
            jKVb("completed",  r.completed),
            jKVd("cost",       r.cost, 2),
            jKVs("status",     tag)
        }));
    };
    for (auto& r : due)      addRec(r, "due");
    for (auto& r : upcoming) addRec(r, "upcoming");
    return arr(items);
}

std::string ApiServer::serializeGeofences() {
    auto zones = m_fleet.getGeofences().getAllZones();
    std::string items;
    bool first = true;
    for (auto& z : zones) {
        if (!first) items += ',';
        first = false;
        std::string typeStr;
        switch (z.type) {
            case ZoneType::FAIRWAY:          typeStr = "fairway"; break;
            case ZoneType::GREEN:            typeStr = "green"; break;
            case ZoneType::CART_PATH:        typeStr = "cart_path"; break;
            case ZoneType::PARKING:          typeStr = "parking"; break;
            case ZoneType::RESTRICTED:       typeStr = "restricted"; break;
            case ZoneType::CHARGING_STATION: typeStr = "charging"; break;
        }
        items += obj(joinFields({
            jKVi("id",           z.id),
            jKVs("name",         z.name),
            jKVs("type",         typeStr),
            jKVd("lat",          z.center.latitude,  6),
            jKVd("lon",          z.center.longitude, 6),
            jKVd("radiusMeters", z.radiusMeters, 0),
            jKVd("speedLimit",   z.speedLimitKmh, 0),
            jKVb("accessAllowed",z.accessAllowed)
        }));
    }
    return arr(items);
}

std::string ApiServer::serializeRevenue() {
    return obj(joinFields({
        jKVd("today",    m_fleet.getBookings().getTodayRevenue(), 2),
        jKVd("month",    m_fleet.getBookings().getMonthRevenue(), 2),
        jKVd("total",    m_fleet.getBookings().getTotalRevenue(), 2),
        jKVi("todayBookings", (int)m_fleet.getBookings().getTodaysBookings().size())
    }));
}

std::string ApiServer::serializeTowerStatus() {
    auto offline = m_fleet.getTower().getOfflineCarts();
    std::string offlineArr;
    for (size_t i = 0; i < offline.size(); ++i) {
        if (i) offlineArr += ',';
        offlineArr += std::to_string(offline[i]);
    }
    return obj(joinFields({
        jKVb("running",       m_fleet.getTower().getOfflineCarts().empty()),
        jKVi("offlineCount",  (int)offline.size()),
        std::string("\"offlineCarts\":") + arr(offlineArr)
    }));
}

} // namespace GolfCart
