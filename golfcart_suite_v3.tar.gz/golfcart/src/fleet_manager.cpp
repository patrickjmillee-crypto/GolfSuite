#include "fleet_manager.h"
#include <iostream>
#include <iomanip>
#include <algorithm>
#include <ctime>
#include <cmath>

namespace GolfCart {

FleetManager::FleetManager() {}

FleetManager::~FleetManager() { stop(); }

void FleetManager::initialize() {
    // Load geofences and charging stations
    m_chargers.loadDefaultStations();

    // Wire tower handlers
    m_tower.setTelemetryHandler([this](const CartTelemetry& t) {
        onTelemetry(t);
    });
    m_tower.setAlertHandler([this](const Alert& a) {
        onAlert(a);
    });

    setupDefaultFleet();
}

void FleetManager::start() {
    m_tower.start();
    for (auto& [id, cart] : m_carts) cart->start();
}

void FleetManager::stop() {
    for (auto& [id, cart] : m_carts) cart->stop();
    m_tower.stop();
}

CartAgent* FleetManager::addCart(const CartConfig& config) {
    std::lock_guard<std::mutex> lock(m_mutex);
    auto agent = std::make_unique<CartAgent>(config, &m_geofences, &m_tower);
    CartAgent* ptr = agent.get();
    m_carts[config.id] = std::move(agent);
    return ptr;
}

void FleetManager::removeCart(int cartId) {
    std::lock_guard<std::mutex> lock(m_mutex);
    m_carts.erase(cartId);
}

CartAgent* FleetManager::getCart(int cartId) {
    std::lock_guard<std::mutex> lock(m_mutex);
    auto it = m_carts.find(cartId);
    return it != m_carts.end() ? it->second.get() : nullptr;
}

std::vector<CartAgent*> FleetManager::getAllCarts() {
    std::lock_guard<std::mutex> lock(m_mutex);
    std::vector<CartAgent*> result;
    for (auto& [id, c] : m_carts) result.push_back(c.get());
    return result;
}

std::vector<CartAgent*> FleetManager::getAvailableCarts() {
    std::lock_guard<std::mutex> lock(m_mutex);
    std::vector<CartAgent*> result;
    for (auto& [id, c] : m_carts)
        if (c->getStatus() == CartStatus::AVAILABLE) result.push_back(c.get());
    return result;
}

void FleetManager::emergencyStopAll(const std::string& reason) {
    for (auto& [id, cart] : m_carts) cart->emergencyStop();
    m_tower.broadcastToAll("EMERGENCY_STOP");

    Alert a;
    a.cartId    = 0;
    a.level     = AlertLevel::CRITICAL;
    a.category  = "fleet";
    a.message   = "FLEET EMERGENCY STOP: " + reason;
    a.timestamp = std::time(nullptr);
    onAlert(a);
}

void FleetManager::broadcastMessage(const std::string& msg) {
    m_tower.broadcastToAll(msg);
}

void FleetManager::capAllSpeeds(double maxKmh) {
    m_tower.broadcastToAll("SPEED_CAP:" + std::to_string(maxKmh));
}

FleetStats FleetManager::getStats() const {
    std::lock_guard<std::mutex> lock(m_mutex);
    FleetStats s;
    s.totalCarts = (int)m_carts.size();

    double totalBatt = 0.0;
    double totalSpeed = 0.0;
    int movingCount = 0;

    for (auto& [id, cart] : m_carts) {
        auto tel = cart->getTelemetry();
        switch (tel.status) {
            case CartStatus::AVAILABLE:   s.availableCarts++;   break;
            case CartStatus::IN_USE:      s.inUseCarts++;       break;
            case CartStatus::CHARGING:    s.chargingCarts++;    break;
            case CartStatus::MAINTENANCE: s.maintenanceCarts++; break;
            case CartStatus::OFFLINE:     s.offlineCarts++;     break;
            default: break;
        }
        totalBatt += tel.battery.chargePercent;
        if (tel.motion.isMoving) {
            totalSpeed += tel.motion.speedKmh;
            movingCount++;
        }
    }

    if (s.totalCarts > 0) s.avgBatteryPct = totalBatt / s.totalCarts;
    if (movingCount > 0)  s.avgSpeedKmh   = totalSpeed / movingCount;

    {
        // Alerts from our local log (no re-locking)
        int active = 0;
        for (auto& a : m_alerts)
            if (!a.acknowledged) active++;
        s.activeAlerts = active;
    }

    s.todayRevenue  = m_bookings.getTodayRevenue();
    s.todayBookings = (int)m_bookings.getTodaysBookings().size();
    return s;
}

std::vector<Alert> FleetManager::getRecentAlerts(int n) const {
    std::lock_guard<std::mutex> lock(m_mutex);
    if ((int)m_alerts.size() <= n) return m_alerts;
    return std::vector<Alert>(m_alerts.end() - n, m_alerts.end());
}

void FleetManager::clearAlert(int alertId) {
    std::lock_guard<std::mutex> lock(m_mutex);
    for (auto& a : m_alerts)
        if (a.id == alertId) { a.acknowledged = true; break; }
}

void FleetManager::setupDefaultFleet() {
    struct CartDef { int id; const char* name; const char* model; const char* color; };
    static const CartDef defs[] = {
        {1, "Cart #1",  "Club Car Tempo", "White"},
        {2, "Cart #2",  "Club Car Tempo", "White"},
        {3, "Cart #3",  "E-Z-GO RXV",    "Blue"},
        {4, "Cart #4",  "E-Z-GO RXV",    "Blue"},
        {5, "Cart #5",  "Yamaha Drive2",  "Green"},
        {6, "Cart #6",  "Yamaha Drive2",  "Green"},
        {7, "Cart #7",  "Club Car Tempo", "White"},
        {8, "Cart #8",  "E-Z-GO Express", "Red"},
    };

    for (auto& d : defs) {
        CartConfig cfg;
        cfg.id             = d.id;
        cfg.name           = d.name;
        cfg.model          = d.model;
        cfg.color          = d.color;
        cfg.serialNumber   = "GC-2024-" + std::to_string(1000 + d.id);
        cfg.batteryCapacityAh = 100.0;
        cfg.maxSpeedKmh    = 25.0;
        cfg.seatCapacity   = 4;
        addCart(cfg);
    }

    // Pre-seed some bookings and maintenance for demo
    std::time_t now = std::time(nullptr);

    // Sample bookings
    m_bookings.createBooking("John Smith",    "555-1001", "C001",
        now - 3600, now + 3600, 15.0);
    m_bookings.createBooking("Sarah Johnson", "555-1002", "C002",
        now + 3600, now + 7200, 15.0);
    m_bookings.createBooking("Mike Davis",    "555-1003", "C003",
        now - 7200, now - 3600, 15.0);
    m_bookings.confirmBooking(1, 3);
    m_bookings.startBooking(1);
    m_bookings.confirmBooking(3, 5);
    m_bookings.completeBooking(3);

    // Sample maintenance records
    m_maintenance.scheduleService(2, MaintenanceType::ROUTINE_CHECK,
        now + 86400, "Tom Wilson", "Scheduled 500km check");
    m_maintenance.scheduleService(4, MaintenanceType::BATTERY_SERVICE,
        now - 3600, "Auto-Scheduler", "Battery health at 78%");
    m_maintenance.scheduleService(7, MaintenanceType::TIRE_ROTATION,
        now + 3 * 86400, "Tom Wilson", "Routine tire rotation");

    // Set some cart statuses for demo
    if (auto* c = getCart(3)) c->setStatus(CartStatus::IN_USE);
    if (auto* c = getCart(4)) c->setStatus(CartStatus::MAINTENANCE);
    if (auto* c = getCart(6)) c->setStatus(CartStatus::CHARGING);
}

void FleetManager::onAlert(const Alert& alert) {
    std::lock_guard<std::mutex> lock(m_mutex);
    Alert a   = alert;
    a.id      = m_alertIdCounter++;
    a.timestamp = std::time(nullptr);
    m_alerts.push_back(a);

    // Keep last 200 alerts
    if (m_alerts.size() > 200)
        m_alerts.erase(m_alerts.begin());
}

void FleetManager::onTelemetry(const CartTelemetry& t) {
    // Could store time-series data here or push to a dashboard
    (void)t;
}

void FleetManager::printFleetStatus() const {
    printf("\n  ╔══ FLEET STATUS ═══════════════════════════════════════╗\n");
    for (auto& [id, cart] : m_carts) {
        auto tel = cart->getTelemetry();
        printf("  ║  %-10s │ %-11s │ Batt:%5.1f%% │ %5.1f km/h ║\n",
               cart->getName().c_str(),
               statusToStr(tel.status).c_str(),
               tel.battery.chargePercent,
               tel.motion.speedKmh);
    }
    printf("  ╚═══════════════════════════════════════════════════════╝\n");
}

void FleetManager::printDashboard() const {
    auto stats = getStats();
    printf("\n  ╔══ FLEET DASHBOARD ══════════════════════════════════════╗\n");
    printf("  ║  Total: %-3d  Available: %-3d  In Use: %-3d  Charging: %-3d ║\n",
           stats.totalCarts, stats.availableCarts,
           stats.inUseCarts, stats.chargingCarts);
    printf("  ║  Maintenance: %-3d  Offline: %-3d  Alerts: %-3d           ║\n",
           stats.maintenanceCarts, stats.offlineCarts, stats.activeAlerts);
    printf("  ║  Avg Battery: %.1f%%  │  Today Revenue: $%.2f          ║\n",
           stats.avgBatteryPct, stats.todayRevenue);
    printf("  ╚═════════════════════════════════════════════════════════╝\n");
}

} // namespace GolfCart
