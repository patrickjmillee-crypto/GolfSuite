#include "gps_engine.h"
#include <cmath>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <algorithm>

namespace GolfCart {

// ─── GPSEngine ───────────────────────────────────────────────────────────────

GPSEngine::GPSEngine(int cartId)
    : m_cartId(cartId)
{
    // Default: Pebble Beach Golf Links approximate coords
    m_currentPos = GPSCoordinate(36.5680, -121.9490, 30.0);
    m_currentPos.accuracy = 3.0;
}

GPSCoordinate GPSEngine::readPosition() {
    std::lock_guard<std::mutex> lock(m_mutex);
    if (m_callback) {
        m_callback(m_cartId, m_currentPos);
    }
    return m_currentPos;
}

void GPSEngine::setSimulatedPosition(const GPSCoordinate& pos) {
    std::lock_guard<std::mutex> lock(m_mutex);
    m_currentPos = pos;
    m_currentPos.valid = true;
}

void GPSEngine::simulateMovement(double headingDeg, double speedKmh, double dtSeconds) {
    std::lock_guard<std::mutex> lock(m_mutex);

    double distanceM  = (speedKmh / 3.6) * dtSeconds;
    double headingRad = headingDeg * M_PI / 180.0;

    // Approximate lat/lon delta for small distances
    double deltaLat = (distanceM * std::cos(headingRad)) / 111320.0;
    double deltaLon = (distanceM * std::sin(headingRad)) /
                      (111320.0 * std::cos(m_currentPos.latitude * M_PI / 180.0));

    m_currentPos.latitude  += deltaLat;
    m_currentPos.longitude += deltaLon;
    m_currentPos.valid = true;
}

GPSCoordinate GPSEngine::parseNMEA(const std::string& sentence) {
    // Minimal GPRMC parser for real hardware integration
    GPSCoordinate pos;
    if (sentence.substr(0, 6) != "$GPRMC") return pos;

    std::istringstream ss(sentence);
    std::string token;
    std::vector<std::string> fields;
    while (std::getline(ss, token, ',')) fields.push_back(token);

    if (fields.size() < 7) return pos;
    if (fields[2] != "A") return pos; // 'A' = valid fix

    // Parse latitude
    double rawLat = std::stod(fields[3]);
    int    latDeg = (int)(rawLat / 100);
    double latMin = rawLat - latDeg * 100;
    pos.latitude  = latDeg + latMin / 60.0;
    if (fields[4] == "S") pos.latitude = -pos.latitude;

    // Parse longitude
    double rawLon = std::stod(fields[5]);
    int    lonDeg = (int)(rawLon / 100);
    double lonMin = rawLon - lonDeg * 100;
    pos.longitude = lonDeg + lonMin / 60.0;
    if (fields[6] == "W") pos.longitude = -pos.longitude;

    pos.valid = true;
    return pos;
}

// ─── GeofenceManager ─────────────────────────────────────────────────────────

GeofenceManager::GeofenceManager() {
    loadDefaultCourseMap();
}

void GeofenceManager::loadDefaultCourseMap() {
    // Sample 18-hole course zones around Pebble Beach coords
    // In production: load from JSON/SQLite config file
    struct ZoneDef {
        const char* name; ZoneType type; double lat; double lon;
        double radius; double speedLimit; bool access;
    };

    static const ZoneDef defaults[] = {
        { "Hole 1 Fairway",    ZoneType::FAIRWAY,         36.5685, -121.9485, 80,  20, true  },
        { "Hole 1 Green",      ZoneType::GREEN,           36.5690, -121.9480, 25,   5, true  },
        { "Hole 2 Fairway",    ZoneType::FAIRWAY,         36.5695, -121.9475, 80,  20, true  },
        { "Hole 2 Green",      ZoneType::GREEN,           36.5700, -121.9470, 25,   5, true  },
        { "Main Cart Path",    ZoneType::CART_PATH,       36.5680, -121.9490, 200, 25, true  },
        { "Parking Lot A",     ZoneType::PARKING,         36.5670, -121.9500, 100, 10, true  },
        { "Charging Bay",      ZoneType::CHARGING_STATION,36.5668, -121.9502, 30,   5, true  },
        { "Maintenance Area",  ZoneType::RESTRICTED,      36.5665, -121.9505, 40,   0, false },
        { "Water Hazard",      ZoneType::RESTRICTED,      36.5688, -121.9460, 20,   0, false },
        { "Clubhouse Zone",    ZoneType::CART_PATH,       36.5675, -121.9508, 60,  10, true  },
    };

    for (auto& d : defaults) {
        GeofenceZone z;
        z.id            = m_nextZoneId++;
        z.name          = d.name;
        z.type          = d.type;
        z.center        = GPSCoordinate(d.lat, d.lon);
        z.radiusMeters  = d.radius;
        z.speedLimitKmh = d.speedLimit;
        z.accessAllowed = d.access;
        m_zones.push_back(z);
    }
}

void GeofenceManager::addZone(const GeofenceZone& zone) {
    std::lock_guard<std::mutex> lock(m_mutex);
    m_zones.push_back(zone);
}

void GeofenceManager::removeZone(int zoneId) {
    std::lock_guard<std::mutex> lock(m_mutex);
    m_zones.erase(std::remove_if(m_zones.begin(), m_zones.end(),
        [zoneId](const GeofenceZone& z){ return z.id == zoneId; }), m_zones.end());
}

const GeofenceZone* GeofenceManager::getZone(int zoneId) const {
    std::lock_guard<std::mutex> lock(m_mutex);
    for (auto& z : m_zones) if (z.id == zoneId) return &z;
    return nullptr;
}

std::vector<GeofenceZone> GeofenceManager::getAllZones() const {
    std::lock_guard<std::mutex> lock(m_mutex);
    return m_zones;
}

std::vector<int> GeofenceManager::getActiveZones(const GPSCoordinate& pos) const {
    std::lock_guard<std::mutex> lock(m_mutex);
    std::vector<int> active;
    for (auto& z : m_zones) {
        if (z.contains(pos)) active.push_back(z.id);
    }
    return active;
}

void GeofenceManager::updateCartPosition(int cartId, const GPSCoordinate& pos) {
    std::vector<int> newZones = getActiveZones(pos);

    std::lock_guard<std::mutex> lock(m_mutex);
    auto& prev = m_cartActiveZones[cartId];

    // Detect entries
    for (int zid : newZones) {
        if (std::find(prev.begin(), prev.end(), zid) == prev.end()) {
            const GeofenceZone* z = nullptr;
            for (auto& zz : m_zones) if (zz.id == zid) { z = &zz; break; }
            if (z && m_violationCb) m_violationCb(cartId, *z, true);
        }
    }
    // Detect exits
    for (int zid : prev) {
        if (std::find(newZones.begin(), newZones.end(), zid) == newZones.end()) {
            const GeofenceZone* z = nullptr;
            for (auto& zz : m_zones) if (zz.id == zid) { z = &zz; break; }
            if (z && m_violationCb) m_violationCb(cartId, *z, false);
        }
    }
    prev = newZones;
}

double GeofenceManager::getSpeedLimit(const GPSCoordinate& pos) const {
    std::lock_guard<std::mutex> lock(m_mutex);
    double limit = 25.0; // default
    for (auto& z : m_zones) {
        if (z.contains(pos) && z.speedLimitKmh < limit) {
            limit = z.speedLimitKmh;
        }
    }
    return limit;
}

bool GeofenceManager::isRestricted(const GPSCoordinate& pos) const {
    std::lock_guard<std::mutex> lock(m_mutex);
    for (auto& z : m_zones) {
        if (!z.accessAllowed && z.contains(pos)) return true;
    }
    return false;
}

void GeofenceManager::printZoneMap() const {
    std::lock_guard<std::mutex> lock(m_mutex);
    std::cout << "\n  ╔══ GEOFENCE ZONES ══════════════════════════════════════╗\n";
    for (auto& z : m_zones) {
        std::string typeStr;
        switch (z.type) {
            case ZoneType::FAIRWAY:          typeStr = "FAIRWAY   "; break;
            case ZoneType::GREEN:            typeStr = "GREEN     "; break;
            case ZoneType::CART_PATH:        typeStr = "CART PATH "; break;
            case ZoneType::PARKING:          typeStr = "PARKING   "; break;
            case ZoneType::RESTRICTED:       typeStr = "RESTRICTED"; break;
            case ZoneType::CHARGING_STATION: typeStr = "CHARGING  "; break;
        }
        printf("  ║ [%2d] %-22s │ %-10s │ %5.1f km/h │ R:%.0fm ║\n",
               z.id, z.name.c_str(), typeStr.c_str(),
               z.speedLimitKmh, z.radiusMeters);
    }
    std::cout << "  ╚═══════════════════════════════════════════════════════════╝\n";
}

} // namespace GolfCart
