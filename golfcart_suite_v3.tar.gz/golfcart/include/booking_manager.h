#pragma once
#include "types.h"
#include <vector>
#include <string>
#include <functional>
#include <mutex>
#include <optional>

namespace GolfCart {

// ─── Booking Manager ─────────────────────────────────────────────────────────

class BookingManager {
public:
    using BookingCallback = std::function<void(const Booking&)>;

    BookingManager();

    // CRUD
    int  createBooking(const std::string& customerName,
                       const std::string& customerPhone,
                       const std::string& customerId,
                       std::time_t startTime,
                       std::time_t endTime,
                       double ratePerHour = 15.0,
                       const std::string& notes = "");

    bool confirmBooking(int bookingId, int cartId);
    bool startBooking(int bookingId);
    bool completeBooking(int bookingId);
    bool cancelBooking(int bookingId, const std::string& reason = "");

    // Queries
    std::optional<Booking>        getBooking(int id) const;
    std::vector<Booking>          getActiveBookings() const;
    std::vector<Booking>          getPendingBookings() const;
    std::vector<Booking>          getBookingsForCart(int cartId) const;
    std::vector<Booking>          getBookingsForCustomer(const std::string& customerId) const;
    std::vector<Booking>          getTodaysBookings() const;

    // Availability
    bool isCartAvailable(int cartId, std::time_t start, std::time_t end) const;
    std::vector<int> getAvailableCarts(std::time_t start, std::time_t end,
                                        const std::vector<int>& allCartIds) const;

    // Revenue
    double getTodayRevenue() const;
    double getMonthRevenue() const;
    double getTotalRevenue() const;

    // Callbacks
    void setBookingCallback(BookingCallback cb) { m_bookingCb = cb; }

    void printBookings() const;
    void printRevenueSummary() const;

private:
    std::vector<Booking>  m_bookings;
    int                   m_nextId = 1;
    BookingCallback       m_bookingCb;
    mutable std::mutex    m_mutex;

    Booking* findBooking(int id);
    const Booking* findBooking(int id) const;
    double calculateCost(std::time_t start, std::time_t end, double rate) const;
};

} // namespace GolfCart
