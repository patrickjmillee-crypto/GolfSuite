#pragma once
#include "types.h"
#include "gps_engine.h"
#include "battery_monitor.h"
#include "speed_controller.h"
#include "tower_comm.h"
#include <memory>
#include <thread>
#include <atomic>
#include <mutex>
#include <string>

namespace GolfCart {

// ─── Cart Configuration ──────────────────────────────────────────────────────

struct CartConfig {
    int         id;
    std::string name;           // e.g. "Cart #7"
    std::string serialNumber;
    std::string model;
    double      batteryCapacityAh = 100.0;
    double      maxSpeedKmh       = 25.0;
    double      weightKg          = 280.0;
    std::string color;
    int         seatCapacity      = 4;
};

// ─── Cart Agent ──────────────────────────────────────────────────────────────
// Represents a single golf cart. Runs its own telemetry loop.

class CartAgent {
public:
    explicit CartAgent(const CartConfig& config, GeofenceManager* geofences,
                       TowerComm* tower);
    ~CartAgent();

    void start();
    void stop();

    // Accessors
    int               getId()     const { return m_config.id; }
    std::string       getName()   const { return m_config.name; }
    CartStatus        getStatus() const;
    CartTelemetry     getTelemetry() const;
    const CartConfig& getConfig() const { return m_config; }

    // Driver commands (local or remote)
    void setTargetSpeed(double kmh);
    void emergencyStop();
    void releaseStop();
    void startCharging(int stationId);
    void stopCharging();

    // Remote commands from tower
    void applyRemoteCommand(const std::string& cmd);

    // Status updates
    void setStatus(CartStatus s);

    // Subsystem accessors
    BatteryMonitor& getBattery()  { return *m_battery; }
    SpeedController& getSpeed()   { return *m_speed; }
    GPSEngine&       getGPS()     { return *m_gps; }
    SafetySystem&    getSafety()  { return *m_safety; }
    CartRadio&       getRadio()   { return *m_radio; }

    void printStatus() const;

private:
    CartConfig                        m_config;
    CartStatus                        m_status = CartStatus::AVAILABLE;

    std::unique_ptr<GPSEngine>        m_gps;
    std::unique_ptr<BatteryMonitor>   m_battery;
    std::unique_ptr<SpeedController>  m_speed;
    std::unique_ptr<SafetySystem>     m_safety;
    std::unique_ptr<CartRadio>        m_radio;

    GeofenceManager*  m_geofences;
    TowerComm*        m_tower;

    std::thread       m_telemetryThread;
    std::atomic<bool> m_running{false};
    mutable std::mutex m_mutex;

    int               m_tickCount    = 0;
    static constexpr double TICK_HZ  = 2.0;   // 2 Hz telemetry loop
    static constexpr double DT       = 1.0 / TICK_HZ;

    void telemetryLoop();
    void processTick();
    CartTelemetry buildTelemetry() const;
};

} // namespace GolfCart
