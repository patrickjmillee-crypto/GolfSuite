#pragma once
#include "types.h"
#include <functional>
#include <mutex>

namespace GolfCart {

// ─── Speed Controller ────────────────────────────────────────────────────────
// Enforces zone-based speed limits and safety rules.
// Interfaces with motor controller via PWM / CAN bus on real hardware.

class SpeedController {
public:
    using SpeedAlertCallback = std::function<void(int cartId, const Alert&)>;

    explicit SpeedController(int cartId);

    // Set target speed (from driver input or remote command)
    void  setTargetSpeed(double kmh);

    // Apply zone-based limit override
    void  applyZoneLimit(double maxKmh);

    // Safety overrides
    void  emergencyStop();
    void  releaseEmergencyStop();
    bool  isEmergencyStopped() const { return m_emergencyStop; }

    // Simulate physics tick (dt in seconds)
    void  tick(double dtSeconds);

    // Current motion state
    MotionState getMotionState() const;

    // Update from external sensor (real hardware)
    void  setMeasuredSpeed(double kmh);

    // Global limits
    void  setAbsoluteMaxSpeed(double kmh) { m_absoluteMax = kmh; }

    // Remote speed cap from tower (0 = no cap)
    void  setRemoteCap(double kmh);
    void  clearRemoteCap();

    // Speeding detection
    bool  isSpeeding()   const;
    double getSpeedExcess() const;

    void  setAlertCallback(SpeedAlertCallback cb) { m_alertCb = cb; }
    void  printStatus() const;

private:
    int          m_cartId;
    MotionState  m_motion;
    double       m_targetSpeed    = 0.0;
    double       m_zoneLimit      = 25.0;
    double       m_remoteCapKmh   = 0.0;   // 0 = disabled
    double       m_absoluteMax    = 25.0;
    bool         m_emergencyStop  = false;
    double       m_acceleration   = 5.0;   // km/h per second
    double       m_deceleration   = 10.0;

    SpeedAlertCallback m_alertCb;
    mutable std::mutex m_mutex;

    double effectiveLimit() const;
    void   checkSpeedViolation();
};

// ─── Safety System ───────────────────────────────────────────────────────────

class SafetySystem {
public:
    using SafetyCallback = std::function<void(int cartId, const Alert&)>;

    explicit SafetySystem(int cartId);

    // Run full safety check cycle
    void runCheck(const CartTelemetry& telemetry);

    // Individual checks
    bool checkGeofenceViolation(const GPSCoordinate& pos, bool restricted);
    bool checkSpeedViolation(double speed, double limit);
    bool checkBatteryLow(const BatteryState& battery);
    bool checkTemperature(double tempC);
    bool checkTilt(double pitchDeg, double rollDeg);

    // Safety lockout
    void  lockCart(const std::string& reason);
    void  unlockCart(const std::string& authorizedBy);
    bool  isLocked() const { return m_locked; }

    void setCallback(SafetyCallback cb) { m_cb = cb; }
    void printSafetyLog() const;

private:
    int               m_cartId;
    bool              m_locked      = false;
    std::string       m_lockReason;
    std::vector<Alert> m_safetyLog;
    SafetyCallback    m_cb;
    mutable std::mutex m_mutex;
    int               m_alertIdCounter = 1;

    void emitAlert(AlertLevel level, const std::string& category,
                   const std::string& msg);
};

} // namespace GolfCart
