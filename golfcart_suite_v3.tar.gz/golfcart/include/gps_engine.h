#pragma once
#include "types.h"
#include <vector>
#include <functional>
#include <unordered_map>
#include <mutex>

namespace GolfCart {

// ─── GPS Engine ──────────────────────────────────────────────────────────────
// Simulates GPS reads on RPi; in production swap readGPS() for a real
// NMEA parser (e.g. /dev/ttyS0 with a NEO-6M module).

class GPSEngine {
public:
    using PositionCallback = std::function<void(int cartId, const GPSCoordinate&)>;

    explicit GPSEngine(int cartId);

    // Simulate or read real GPS position
    GPSCoordinate readPosition();

    // Set simulated position (testing / demo mode)
    void setSimulatedPosition(const GPSCoordinate& pos);
    void simulateMovement(double headingDeg, double speedKmh, double dtSeconds);

    void setPositionCallback(PositionCallback cb) { m_callback = cb; }

    bool isLocked() const { return m_locked; }
    int  getSatelliteCount() const { return m_satCount; }

    // Parse NMEA sentence (for real hardware integration)
    static GPSCoordinate parseNMEA(const std::string& sentence);

private:
    int             m_cartId;
    GPSCoordinate   m_currentPos;
    bool            m_locked      = true;
    int             m_satCount    = 8;
    bool            m_simMode     = true;
    PositionCallback m_callback;
    mutable std::mutex m_mutex;
};

// ─── Geofence Manager ────────────────────────────────────────────────────────

class GeofenceManager {
public:
    using ViolationCallback = std::function<void(int cartId, const GeofenceZone&, bool entered)>;

    GeofenceManager();

    // Zone management
    void addZone(const GeofenceZone& zone);
    void removeZone(int zoneId);
    const GeofenceZone* getZone(int zoneId) const;
    std::vector<GeofenceZone> getAllZones() const;

    // Load default golf course map zones
    void loadDefaultCourseMap();

    // Check position against all zones; fires callbacks on enter/exit
    std::vector<int> getActiveZones(const GPSCoordinate& pos) const;
    void             updateCartPosition(int cartId, const GPSCoordinate& pos);

    // Speed limit for current position
    double getSpeedLimit(const GPSCoordinate& pos) const;

    // Restricted zone check
    bool isRestricted(const GPSCoordinate& pos) const;

    void setViolationCallback(ViolationCallback cb) { m_violationCb = cb; }

    void printZoneMap() const;

private:
    std::vector<GeofenceZone>              m_zones;
    std::unordered_map<int, std::vector<int>> m_cartActiveZones; // cartId → [zoneIds]
    ViolationCallback                      m_violationCb;
    mutable std::mutex                     m_mutex;
    int                                    m_nextZoneId = 1;
};

} // namespace GolfCart
