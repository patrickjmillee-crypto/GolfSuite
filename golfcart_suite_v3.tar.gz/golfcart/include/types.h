#pragma once
#include <string>
#include <chrono>
#include <ctime>

namespace GolfCart {

// ─── Enumerations ────────────────────────────────────────────────────────────

enum class CartStatus {
    AVAILABLE,
    IN_USE,
    CHARGING,
    MAINTENANCE,
    OFFLINE,
    RESERVED
};

enum class AlertLevel {
    INFO,
    WARNING,
    CRITICAL
};

enum class MaintenanceType {
    ROUTINE_CHECK,
    BATTERY_SERVICE,
    TIRE_ROTATION,
    BRAKE_INSPECTION,
    MOTOR_SERVICE,
    SOFTWARE_UPDATE,
    FULL_SERVICE
};

enum class BookingStatus {
    PENDING,
    CONFIRMED,
    ACTIVE,
    COMPLETED,
    CANCELLED
};

enum class ZoneType {
    FAIRWAY,
    GREEN,
    CART_PATH,
    PARKING,
    RESTRICTED,
    CHARGING_STATION
};

// ─── GPS Coordinate ──────────────────────────────────────────────────────────

struct GPSCoordinate {
    double latitude  = 0.0;
    double longitude = 0.0;
    double altitude  = 0.0;
    double accuracy  = 0.0;   // meters
    bool   valid     = false;

    GPSCoordinate() = default;
    GPSCoordinate(double lat, double lon, double alt = 0.0)
        : latitude(lat), longitude(lon), altitude(alt), valid(true) {}

    // Haversine distance in meters
    double distanceTo(const GPSCoordinate& other) const;
};

// ─── Battery State ───────────────────────────────────────────────────────────

struct BatteryState {
    double  chargePercent    = 100.0;   // 0–100
    double  voltageV         = 48.0;
    double  currentA         = 0.0;
    double  temperatureC     = 25.0;
    double  capacityAh       = 100.0;
    bool    isCharging       = false;
    int     cycleCount       = 0;
    double  healthPercent    = 100.0;

    bool    lowBattery()     const { return chargePercent < 20.0; }
    bool    criticalBattery()const { return chargePercent < 10.0; }
    double  estimatedRangeKm()const;
};

// ─── Speed / Motion State ────────────────────────────────────────────────────

struct MotionState {
    double  speedKmh         = 0.0;
    double  maxAllowedKmh    = 25.0;
    double  heading          = 0.0;   // degrees 0–360
    bool    isMoving         = false;
    bool    speedLimitActive = true;
    double  odometryKm       = 0.0;
};

// ─── Geofence Zone ───────────────────────────────────────────────────────────

struct GeofenceZone {
    int            id;
    std::string    name;
    ZoneType       type;
    GPSCoordinate  center;
    double         radiusMeters;
    double         speedLimitKmh;
    bool           accessAllowed;

    bool contains(const GPSCoordinate& pos) const;
};

// ─── Alert ───────────────────────────────────────────────────────────────────

struct Alert {
    int         id;
    int         cartId;
    AlertLevel  level;
    std::string message;
    std::string category;   // "battery", "speed", "geofence", "maintenance"
    std::time_t timestamp;
    bool        acknowledged = false;

    std::string levelStr() const;
    std::string timeStr()  const;
};

// ─── Booking ─────────────────────────────────────────────────────────────────

struct Booking {
    int           id;
    int           cartId        = -1;
    std::string   customerName;
    std::string   customerPhone;
    std::string   customerId;
    std::time_t   startTime;
    std::time_t   endTime;
    BookingStatus status        = BookingStatus::PENDING;
    double        totalCost     = 0.0;
    double        ratePerHour   = 15.0;
    std::string   notes;

    double durationHours() const;
    std::string statusStr() const;
};

// ─── Maintenance Record ──────────────────────────────────────────────────────

struct MaintenanceRecord {
    int             id;
    int             cartId;
    MaintenanceType type;
    std::time_t     scheduledDate;
    std::time_t     completedDate = 0;
    bool            completed     = false;
    std::string     technicianName;
    std::string     notes;
    double          cost          = 0.0;

    std::string typeStr() const;
};

// ─── Cart Telemetry (full snapshot) ─────────────────────────────────────────

struct CartTelemetry {
    int           cartId;
    std::time_t   timestamp;
    GPSCoordinate position;
    BatteryState  battery;
    MotionState   motion;
    CartStatus    status;
    int           activeZoneId   = -1;
    double        upTimeHours    = 0.0;
};

// ─── Utility ─────────────────────────────────────────────────────────────────

std::string statusToStr(CartStatus s);
std::string timeToStr(std::time_t t);
std::string currentTimeStr();

} // namespace GolfCart
