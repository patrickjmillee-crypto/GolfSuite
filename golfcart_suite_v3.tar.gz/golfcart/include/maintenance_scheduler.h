#pragma once
#include "types.h"
#include <vector>
#include <functional>
#include <mutex>
#include <optional>

namespace GolfCart {

// ─── Maintenance Scheduler ───────────────────────────────────────────────────

class MaintenanceScheduler {
public:
    using MaintenanceCallback = std::function<void(const MaintenanceRecord&)>;

    MaintenanceScheduler();

    // Schedule maintenance
    int scheduleService(int cartId,
                        MaintenanceType type,
                        std::time_t scheduledDate,
                        const std::string& technician = "",
                        const std::string& notes = "");

    // Complete a maintenance record
    bool completeService(int recordId,
                         const std::string& technicianName,
                         const std::string& notes,
                         double cost);

    // Auto-schedule based on usage
    void autoSchedule(int cartId, double odometryKm,
                      int battCycleCount, double battHealthPct);

    // Queries
    std::optional<MaintenanceRecord>   getRecord(int id) const;
    std::vector<MaintenanceRecord>     getDueServices() const;
    std::vector<MaintenanceRecord>     getOverdueServices() const;
    std::vector<MaintenanceRecord>     getCartHistory(int cartId) const;
    std::vector<MaintenanceRecord>     getUpcomingServices(int daysAhead = 7) const;

    bool isCartDueForService(int cartId) const;

    // Cost analysis
    double getTotalMaintenanceCost(int cartId) const;
    double getAverageServiceCost() const;

    void setCallback(MaintenanceCallback cb) { m_cb = cb; }

    void printSchedule() const;
    void printCartHistory(int cartId) const;

private:
    std::vector<MaintenanceRecord> m_records;
    int                            m_nextId = 1;
    MaintenanceCallback            m_cb;
    mutable std::mutex             m_mutex;

    // Thresholds for auto-scheduling
    static constexpr double ROUTINE_CHECK_KM      = 500.0;
    static constexpr double TIRE_ROTATION_KM      = 1000.0;
    static constexpr double MOTOR_SERVICE_KM      = 5000.0;
    static constexpr double BATTERY_SERVICE_CYCLES = 100;
    static constexpr double BATTERY_HEALTH_THRESHOLD = 80.0;
};

} // namespace GolfCart
