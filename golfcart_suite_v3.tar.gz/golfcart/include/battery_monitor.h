#pragma once
#include "types.h"
#include <functional>
#include <deque>
#include <mutex>

namespace GolfCart {

// ─── Battery Monitor ─────────────────────────────────────────────────────────
// On real RPi hardware, reads via I2C (e.g. INA219 / BQ34Z100).
// In simulation mode, models discharge / charge curves.

class BatteryMonitor {
public:
    using AlertCallback = std::function<void(int cartId, const Alert&)>;

    explicit BatteryMonitor(int cartId, double capacityAh = 100.0);

    // Read current battery state
    BatteryState readState();

    // Simulate discharge (watt draw, dt in seconds)
    void simulateDischarge(double powerWatts, double dtSeconds);
    void simulateCharge(double chargeRateA, double dtSeconds);

    // Force state (for real hardware reads)
    void setState(const BatteryState& state);

    // Thresholds
    void setLowBatteryThreshold(double pct)      { m_lowPct  = pct; }
    void setCriticalThreshold(double pct)         { m_critPct = pct; }

    // History (last N readings for trend analysis)
    std::deque<BatteryState> getHistory() const;
    double getAverageDischargRateAh() const;

    // Health estimation
    double estimateHealthPercent() const;

    void setAlertCallback(AlertCallback cb) { m_alertCb = cb; }

    // Pretty print
    void printStatus() const;

private:
    int              m_cartId;
    BatteryState     m_state;
    double           m_lowPct  = 20.0;
    double           m_critPct = 10.0;
    std::deque<BatteryState> m_history;
    static constexpr size_t HISTORY_SIZE = 100;
    AlertCallback    m_alertCb;
    mutable std::mutex m_mutex;

    void checkThresholds();
    void recordHistory();
};

// ─── Charging Station ────────────────────────────────────────────────────────

struct ChargingStation {
    int           id;
    std::string   name;
    GPSCoordinate location;
    int           totalPorts;
    int           availablePorts;
    double        maxChargeRateKw;
    bool          isOperational = true;

    bool hasAvailablePort() const { return availablePorts > 0; }
};

class ChargingStationManager {
public:
    void addStation(const ChargingStation& station);
    void loadDefaultStations();

    ChargingStation*       findNearest(const GPSCoordinate& pos);
    const ChargingStation* getStation(int id) const;
    std::vector<ChargingStation> getAvailableStations() const;

    bool  dockCart(int cartId, int stationId, int port);
    bool  undockCart(int cartId);

    void  printStations() const;

private:
    std::vector<ChargingStation>      m_stations;
    std::unordered_map<int,int>       m_cartDocked; // cartId → stationId
    mutable std::mutex                m_mutex;
};

} // namespace GolfCart
