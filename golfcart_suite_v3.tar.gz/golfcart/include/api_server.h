#pragma once
#include "fleet_manager.h"
#include "httplib.h"
#include "embedded_ui.h"
#include <thread>
#include <atomic>
#include <string>
#include <sstream>

namespace GolfCart {

// ─── JSON helpers (no external deps) ─────────────────────────────────────────

inline std::string jStr(const std::string& s) {
    return "\"" + s + "\"";
}
inline std::string jKV(const std::string& k, const std::string& v) {
    return "\"" + k + "\":" + v;
}
inline std::string jKVs(const std::string& k, const std::string& v) {
    return "\"" + k + "\":\"" + v + "\"";
}
inline std::string jKVd(const std::string& k, double v, int prec = 2) {
    std::ostringstream oss;
    oss << std::fixed << std::setprecision(prec);
    oss << "\"" << k << "\":" << v;
    return oss.str();
}
inline std::string jKVi(const std::string& k, int v) {
    return "\"" + k + "\":" + std::to_string(v);
}
inline std::string jKVb(const std::string& k, bool v) {
    return "\"" + k + "\":" + (v ? "true" : "false");
}
inline std::string obj(const std::string& fields) { return "{" + fields + "}"; }
inline std::string arr(const std::string& items)  { return "[" + items + "]"; }

// ─── API Server ───────────────────────────────────────────────────────────────

class ApiServer {
public:
    explicit ApiServer(FleetManager& fleet, int port = 8080);
    ~ApiServer();

    void start();
    void stop();
    bool isRunning() const { return m_running.load(); }
    int  getPort()   const { return m_port; }

private:
    FleetManager&        m_fleet;
    int                  m_port;
    httplib::Server      m_svr;
    std::thread          m_thread;
    std::atomic<bool>    m_running{false};

    void setupRoutes();
    void setCORS(httplib::Response& res);

    // Route handlers
    std::string serializeFleetStats();
    std::string serializeCart(CartAgent* cart);
    std::string serializeAllCarts();
    std::string serializeBookings();
    std::string serializeAlerts(int n = 50);
    std::string serializeMaintenance();
    std::string serializeGeofences();
    std::string serializeRevenue();
    std::string serializeTowerStatus();
};

} // namespace GolfCart
