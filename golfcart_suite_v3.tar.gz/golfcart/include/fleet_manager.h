#pragma once
#include "cart_agent.h"
#include "booking_manager.h"
#include "maintenance_scheduler.h"
#include "tower_comm.h"
#include "gps_engine.h"
#include <vector>
#include <memory>
#include <unordered_map>
#include <mutex>

namespace GolfCart {

// ─── Fleet Statistics ────────────────────────────────────────────────────────

struct FleetStats {
    int    totalCarts       = 0;
    int    availableCarts   = 0;
    int    inUseCarts       = 0;
    int    chargingCarts    = 0;
    int    maintenanceCarts = 0;
    int    offlineCarts     = 0;
    double avgBatteryPct    = 0.0;
    double avgSpeedKmh      = 0.0;
    int    activeAlerts     = 0;
    double todayRevenue     = 0.0;
    int    todayBookings    = 0;
};

// ─── Fleet Manager ───────────────────────────────────────────────────────────

class FleetManager {
public:
    FleetManager();
    ~FleetManager();

    void initialize();
    void start();
    void stop();

    // Cart management
    CartAgent* addCart(const CartConfig& config);
    void       removeCart(int cartId);
    CartAgent* getCart(int cartId);
    std::vector<CartAgent*> getAllCarts();
    std::vector<CartAgent*> getAvailableCarts();

    // Fleet-wide commands
    void emergencyStopAll(const std::string& reason);
    void broadcastMessage(const std::string& msg);
    void capAllSpeeds(double maxKmh);

    // Statistics
    FleetStats getStats() const;

    // Subsystem accessors
    BookingManager&       getBookings()     { return m_bookings; }
    MaintenanceScheduler& getMaintenance()  { return m_maintenance; }
    GeofenceManager&      getGeofences()    { return m_geofences; }
    TowerComm&            getTower()        { return m_tower; }

    // Alerts log
    std::vector<Alert>  getRecentAlerts(int n = 20) const;
    void                clearAlert(int alertId);

    void printFleetStatus() const;
    void printDashboard()   const;

private:
    std::unordered_map<int, std::unique_ptr<CartAgent>> m_carts;
    BookingManager       m_bookings;
    MaintenanceScheduler m_maintenance;
    GeofenceManager      m_geofences;
    TowerComm            m_tower;
    ChargingStationManager m_chargers;

    std::vector<Alert>   m_alerts;
    int                  m_alertIdCounter = 1;
    mutable std::mutex   m_mutex;

    void setupDefaultFleet();
    void onAlert(const Alert& alert);
    void onTelemetry(const CartTelemetry& t);
};

} // namespace GolfCart
