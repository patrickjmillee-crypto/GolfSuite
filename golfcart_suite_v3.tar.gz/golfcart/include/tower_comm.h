#pragma once
#include "types.h"
#include <string>
#include <vector>
#include <functional>
#include <thread>
#include <queue>
#include <mutex>
#include <condition_variable>
#include <atomic>

namespace GolfCart {

// ─── Message Protocol ────────────────────────────────────────────────────────

enum class MessageType {
    TELEMETRY_UPDATE,
    ALERT,
    COMMAND,
    HEARTBEAT,
    BOOKING_UPDATE,
    MAINTENANCE_UPDATE,
    EMERGENCY
};

struct Message {
    MessageType  type;
    int          senderId;    // cartId or 0 for tower
    int          targetId;    // cartId or 0 for tower/broadcast
    std::string  payload;     // JSON-style string
    std::time_t  timestamp;
    int          sequenceNum = 0;

    std::string serialize()   const;
    static Message deserialize(const std::string& raw);
    std::string typeStr() const;
};

// ─── Cart Radio (per-cart comm module) ───────────────────────────────────────
// On real RPi: uses socket or serial to talk to tower.
// Here we simulate with in-process queues; drop-in for real TCP/UDP/MQTT.

class CartRadio {
public:
    using MessageHandler = std::function<void(const Message&)>;

    explicit CartRadio(int cartId);
    ~CartRadio();

    void start();
    void stop();

    bool send(const Message& msg);
    void setMessageHandler(MessageHandler handler) { m_handler = handler; }

    // Simulate receiving a message from tower (used by TowerComm)
    void injectMessage(const Message& msg);

    bool isConnected() const { return m_connected.load(); }
    int  getSignalStrength() const { return m_signalStrength; }

private:
    int             m_cartId;
    MessageHandler  m_handler;
    std::atomic<bool> m_running{false};
    std::atomic<bool> m_connected{true};
    int             m_signalStrength = 85; // percent
    std::queue<Message>  m_inboundQueue;
    std::mutex           m_queueMutex;
    std::condition_variable m_cv;
    std::thread          m_workerThread;

    void workerLoop();
};

// ─── Tower Communication Hub ─────────────────────────────────────────────────

class TowerComm {
public:
    using TelemetryHandler    = std::function<void(const CartTelemetry&)>;
    using AlertHandler        = std::function<void(const Alert&)>;
    using CommandHandler      = std::function<void(int cartId, const std::string& cmd)>;

    TowerComm();
    ~TowerComm();

    void start();
    void stop();

    // Register a cart radio with the tower
    void registerCart(int cartId, CartRadio* radio);
    void unregisterCart(int cartId);

    // Broadcast telemetry from a cart to the tower
    void broadcastTelemetry(const CartTelemetry& telemetry);
    void broadcastAlert(const Alert& alert);

    // Tower → cart commands
    bool sendCommand(int cartId, const std::string& command);
    bool sendEmergencyStop(int cartId);
    bool sendSpeedCap(int cartId, double maxKmh);
    bool broadcastToAll(const std::string& command);

    // Heartbeat monitoring
    void sendHeartbeat(int cartId);
    bool isCartResponsive(int cartId) const;
    std::vector<int> getOfflineCarts() const;

    // Handlers
    void setTelemetryHandler(TelemetryHandler h) { m_telemetryHandler = h; }
    void setAlertHandler(AlertHandler h)          { m_alertHandler = h; }

    void printConnectionStatus() const;

private:
    std::unordered_map<int, CartRadio*>  m_radios;
    std::unordered_map<int, std::time_t> m_lastHeartbeat;
    TelemetryHandler   m_telemetryHandler;
    AlertHandler       m_alertHandler;
    mutable std::mutex m_mutex;
    std::atomic<bool>  m_running{false};
    std::thread        m_heartbeatThread;
    int                m_seqCounter = 0;

    void heartbeatLoop();
    void handleIncoming(const Message& msg);
};

} // namespace GolfCart
