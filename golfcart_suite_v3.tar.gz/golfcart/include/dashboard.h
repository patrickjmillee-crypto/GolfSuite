#pragma once
#include "fleet_manager.h"
#include <string>

namespace GolfCart {

// ─── Terminal Dashboard ───────────────────────────────────────────────────────
// ANSI-colored terminal UI for the management tower.

class Dashboard {
public:
    explicit Dashboard(FleetManager& fleet);

    // Interactive main loop
    void run();

    // Individual screens
    void showMainMenu()       const;
    void showFleetOverview()  const;
    void showCartDetails(int cartId) const;
    void showAlerts()         const;
    void showBookings()       const;
    void showMaintenance()    const;
    void showGeofenceMap()    const;
    void showRevenueSummary() const;

    // Commands
    void handleCartCommand();
    void handleBookingCommand();
    void handleMaintenanceCommand();

private:
    FleetManager& m_fleet;

    static void clearScreen();
    static void printHeader(const std::string& title);
    static void printSeparator(char c = '-', int width = 70);
    static void printColored(const std::string& text, const std::string& colorCode);
    static std::string batteryBar(double pct, int width = 10);
    static std::string statusBadge(CartStatus s);
    static std::string alertBadge(AlertLevel l);
    static int         promptInt(const std::string& prompt);
    static std::string promptStr(const std::string& prompt);
};

// ANSI color codes
namespace Color {
    inline constexpr const char* RESET   = "\033[0m";
    inline constexpr const char* BOLD    = "\033[1m";
    inline constexpr const char* RED     = "\033[31m";
    inline constexpr const char* GREEN   = "\033[32m";
    inline constexpr const char* YELLOW  = "\033[33m";
    inline constexpr const char* BLUE    = "\033[34m";
    inline constexpr const char* MAGENTA = "\033[35m";
    inline constexpr const char* CYAN    = "\033[36m";
    inline constexpr const char* WHITE   = "\033[37m";
    inline constexpr const char* BGBLUE  = "\033[44m";
    inline constexpr const char* BGGREEN = "\033[42m";
    inline constexpr const char* BGRED   = "\033[41m";
}

} // namespace GolfCart
