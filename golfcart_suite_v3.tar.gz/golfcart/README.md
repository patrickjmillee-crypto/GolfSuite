# Golf Cart Fleet Management Suite
**Commercial Golf Course Edition — C++17 for Linux / Raspberry Pi**

---

## Architecture Overview

```
golfcart/
├── include/
│   ├── types.h              # Core data types, enums, structs
│   ├── gps_engine.h         # GPS + Geofence engine
│   ├── battery_monitor.h    # Battery state + charging stations
│   ├── speed_controller.h   # Speed limits + safety lockouts
│   ├── booking_manager.h    # Reservations + revenue tracking
│   ├── maintenance_scheduler.h  # Service scheduling + history
│   ├── tower_comm.h         # Cart-to-tower messaging
│   ├── cart_agent.h         # Per-cart autonomous agent
│   ├── fleet_manager.h      # Fleet orchestrator
│   └── dashboard.h          # ANSI terminal UI
├── src/                     # Implementations (one .cpp per module)
├── CMakeLists.txt
└── README.md
```

---

## Modules

### GPS Engine & Geofencing
- Haversine distance calculations
- 10 default course zones (fairways, greens, cart paths, restricted, charging)
- Real-time zone enter/exit callbacks
- Speed limit enforcement per zone
- Restricted zone detection → auto-stop
- Drop-in NMEA parser for real GPS hardware (NEO-6M, etc.)

### Battery Monitor
- Simulated charge/discharge physics (voltage sag, temperature modeling)
- Low battery (20%) and critical (10%) alerts
- Battery health tracking via cycle count
- 100-reading history for trend analysis
- I2C hook point for real hardware (INA219 / BQ34Z100)

### Speed Controller & Safety System
- Zone-based speed limit application
- Remote speed cap from tower
- Absolute max speed enforcement
- Emergency stop (local + remote)
- Tilt, temperature, and geofence safety checks
- Cart lockout with reason tracking

### Booking Manager
- Full booking lifecycle: Pending → Confirmed → Active → Completed
- Availability conflict detection
- Revenue tracking: today / month / total
- Customer history lookup

### Maintenance Scheduler
- Manual and auto-triggered scheduling (odometry, battery cycles, health)
- Overdue service detection
- Per-cart cost history
- Service types: Routine, Battery, Tires, Brakes, Motor, Software, Full

### Tower Communication
- Publish/subscribe message bus (in-process; swap for TCP/MQTT in production)
- Commands: EMERGENCY_STOP, SPEED_CAP, STATUS_REQUEST, CLEAR_SPEED_CAP
- Heartbeat monitoring with 30s offline detection
- All-fleet broadcast

### Cart Agent (Per-Cart Thread)
- 2 Hz autonomous telemetry loop
- Wires all subsystems together
- Handles remote commands from tower
- Simulates realistic movement on the course

### Fleet Manager
- Manages 8 default carts (Club Car, E-Z-GO, Yamaha)
- Fleet-wide emergency stop
- Aggregate statistics dashboard
- Alert log (last 200 events)

### Terminal Dashboard
- ANSI color-coded interactive UI
- Fleet overview with battery bars
- Per-cart detail view
- Alert log, booking list, maintenance schedule
- Revenue summary
- Interactive booking and maintenance creation

---

## Build

```bash
mkdir build && cd build
cmake .. -DCMAKE_BUILD_TYPE=Release
make -j$(nproc)
```

### Dependencies
- CMake >= 3.16
- GCC >= 9 (C++17)
- POSIX threads (pthreads)
- No external libraries required

---

## Run

```bash
# Interactive dashboard (default)
./golfcart_suite

# Demo / headless mode (CI/testing)
./golfcart_suite --demo
```

---

## Real Hardware Integration (Raspberry Pi)

### GPS (NEO-6M via UART)
Replace `GPSEngine::readPosition()` with:
```cpp
// Open /dev/ttyS0 at 9600 baud, read NMEA, call parseNMEA()
GPSCoordinate pos = GPSEngine::parseNMEA(readLineFromSerial());
```

### Battery (INA219 via I2C)
Replace `BatteryMonitor::readState()` with:
```cpp
// i2c_smbus_read_word_data(fd, INA219_REG_CURRENT) etc.
state.voltageV  = readI2C(INA219_BUS_VOLTAGE);
state.currentA  = readI2C(INA219_CURRENT);
```

### Speed (Hall-effect wheel sensor)
Feed measured speed into:
```cpp
cart->getSpeed().setMeasuredSpeed(measuredKmh);
```

### Motor Controller (PWM / CAN)
In `SpeedController::tick()`, map `m_motion.speedKmh` to PWM duty cycle
or CAN message to your motor controller (Kelly, Alltrax, etc.)

---

## Fleet Configuration

Edit `FleetManager::setupDefaultFleet()` to:
- Change cart models, colors, serial numbers
- Adjust battery capacity per cart
- Set max speed limits per cart class

Edit `GeofenceManager::loadDefaultCourseMap()` to:
- Import real GPS coordinates for your course
- Define fairway/green/path/restricted zones
- Set per-zone speed limits

---

## Default Fleet (8 Carts)

| Cart | Model           | Color | Max Speed |
|------|-----------------|-------|-----------|
| #1   | Club Car Tempo  | White | 25 km/h   |
| #2   | Club Car Tempo  | White | 25 km/h   |
| #3   | E-Z-GO RXV      | Blue  | 25 km/h   |
| #4   | E-Z-GO RXV      | Blue  | 25 km/h   |
| #5   | Yamaha Drive2   | Green | 25 km/h   |
| #6   | Yamaha Drive2   | Green | 25 km/h   |
| #7   | Club Car Tempo  | White | 25 km/h   |
| #8   | E-Z-GO Express  | Red   | 25 km/h   |

---

## Extending the System

- **MQTT/TCP networking**: Replace `CartRadio::send()` / `injectMessage()` with socket I/O
- **Database persistence**: Add SQLite to `BookingManager` and `MaintenanceScheduler`
- **Web dashboard**: Expose `FleetManager::getStats()` via a REST API (cpp-httplib)
- **Mobile alerts**: Hook `FleetManager::onAlert()` to Twilio / push notifications
- **Multi-course**: Add `CourseId` to all entities and partition `GeofenceManager`
